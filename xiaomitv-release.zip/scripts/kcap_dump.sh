#!/system/bin/sh
# pcap 落盘: 24B 全局头(LINKTYPE_RAW=101) + /proc/kcap 包记录流
F=/data/adb/kcap_last.pcap
printf '\xd4\xc3\xb2\xa1\x02\x00\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\xff\xff\x00\x00\x65\x00\x00\x00' > $F
cat /proc/kcap >> $F
echo "pcap: $F ($(ls -la $F | awk '{print $5}') bytes)"
