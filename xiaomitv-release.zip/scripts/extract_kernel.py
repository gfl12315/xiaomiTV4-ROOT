# -*- coding: utf-8 -*-
"""extract_kernel.py <固件包.zip 或 boot.img> —— 提取并解压内核 Image"""
import zipfile, struct, gzip, sys

src = sys.argv[1]
if src.endswith('.zip'):
    z = zipfile.ZipFile(src)
    d = z.read('boot.img')
else:
    d = open(src, 'rb').read()

assert d[:8] == b'ANDROID!', '非 Android boot 镜像'
ks = struct.unpack('<I', d[8:12])[0]          # kernel 大小
kern = d[2048:2048 + ks]                       # kernel 数据（紧随 1KB 页头）
print('kernel magic:', kern[:4].hex())
if kern[:2] == b'\x1f\x8b':                    # gzip
    raw = gzip.decompress(kern)
else:
    raw = kern
print('解压后:', len(raw), '字节; Image 魔数(0x38 处):', raw[0x38:0x3c])  # 应为 ARMd
open('vmlinux.img', 'wb').write(raw)
