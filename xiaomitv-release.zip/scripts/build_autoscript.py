#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_autoscript.py — U-Boot legacy script 打包器（aml_autoscript 生成）

格式依据本机 U-Boot 源码（权威）:
  common/cmd_source.c source(): 校验 magic → hcrc → (verify=1 时) dcrc → type==IH_TYPE_SCRIPT,
  数据区 = BE32(脚本总长) + BE32(0 终止标记) + 脚本文本, run_command_list 执行。
  common/image.c: hcrc = CRC32(整个 64B 头, hcrc 字段置 0); dcrc = CRC32(数据区);
  CRC32 多项式与 zlib 一致。verify env 未设置时默认开启, dcrc 必须正确。
  store_interface.c: store write <分区名> <内存地址> <偏移> <大小> 为通用分区写命令。

用法:
  python build_autoscript.py --text rescue.script --out aml_autoscript --name rescue
  python build_autoscript.py --demo            # 生成三份标准脚本到 --outdir
"""
import argparse
import struct
import sys
import zlib

IH_MAGIC = 0x27051956
IH_OS_LINUX = 5
IH_ARCH_ARM = 1
IH_TYPE_SCRIPT = 6
IH_COMP_NONE = 0


def build_script_image(text: str, name: bytes = b"usb_rescue") -> bytes:
    """脚本文本 → legacy U-Boot script image 字节。"""
    script = text.encode("ascii")
    # 数据区: BE32(总长) + BE32(0 终止) + 文本   (cmd_source.c: len=*data; while(*data++);)
    data = struct.pack(">II", len(script), 0) + script
    # 头: image_header_t 9 字段全 BE:
    #   magic/hcrc/time/size/load/ep/dcrc/os:arch:type:comp/name[32]
    # time = 构建时间戳（autoscr 不校验, 照 mkimage 惯例填）
    import time as _time
    stamp = int(_time.time()) & 0xFFFFFFFF
    hdr = struct.pack(
        ">IIIIIIII", IH_MAGIC, 0, stamp, len(data), 0, 0, 0, 0
    )
    # offset 0x1c 处 4 字节 = os/arch/type/comp（覆盖占位）
    hdr = hdr[:28] + bytes([IH_OS_LINUX, IH_ARCH_ARM, IH_TYPE_SCRIPT, IH_COMP_NONE])
    hdr += name[:32].ljust(32, b"\x00")
    assert len(hdr) == 64
    # dcrc 先填（数据 CRC），再算 hcrc（覆盖含 dcrc 的整头, hcrc 字段置 0）
    dcrc = zlib.crc32(data) & 0xFFFFFFFF
    hdr = hdr[:24] + struct.pack(">I", dcrc) + hdr[28:]
    hcrc = zlib.crc32(hdr) & 0xFFFFFFFF
    hdr = hdr[:4] + struct.pack(">I", hcrc) + hdr[8:]
    return hdr + data


def verify_image(blob: bytes) -> bool:
    """回读自检: 按 cmd_source.c 的校验路径逐项复算。"""
    ok = True
    magic, hcrc, tstamp, size, load, ep, dcrc = struct.unpack(">IIIIIII", blob[:28])
    os_, arch, typ, comp = blob[28:32]
    name = blob[32:64].rstrip(b"\x00").decode("ascii", "replace")
    data = blob[64:64 + size]

    if magic != IH_MAGIC:
        print("  magic 错"); ok = False
    if size != len(blob) - 64:
        print("  size 字段与实际数据不符"); ok = False
    # hcrc 复算: 整头 64B, hcrc 字段置 0
    hdr0 = blob[:4] + b"\x00\x00\x00\x00" + blob[8:64]
    if zlib.crc32(hdr0) & 0xFFFFFFFF != hcrc:
        print("  hcrc 错"); ok = False
    # dcrc 复算
    if zlib.crc32(data) & 0xFFFFFFFF != dcrc:
        print("  dcrc 错"); ok = False
    if typ != IH_TYPE_SCRIPT:
        print("  type 不是 SCRIPT"); ok = False

    # 数据区解析: [BE32 总长][BE32 0][文本]
    l1, l2 = struct.unpack(">II", data[:8])
    text = data[8:8 + l1]
    if l2 != 0 or len(text) != l1:
        print("  数据区结构错"); ok = False
    print(f"  头: magic=OK hcrc=OK dcrc=OK type=SCRIPT({typ}) os={os_} arch={arch} time={tstamp}")
    print(f"  数据: 脚本 {l1} 字节, name={name!r}")
    print(f"  首行: {text.splitlines()[0][:60]!r}")
    print(f"  行数: {len(text.splitlines())}")
    return ok


SCRIPTS = {
    # 1) 无害验证: 写入一个 env 标记并重启, 回系统后 ADB 读 env 分区即可闭环
    "test.script": """\
echo === USB AUTOSCRIPT TEST ===
setenv usb_rescue_test ok
saveenv
echo test done, rebooting
reset
""",
    # 2) 引导 U 盘里的 TWRP (不写任何分区, 最安全)
    "rescue.script": """\
echo === USB RESCUE: boot TWRP from udisk ===
if fatload usb 0 ${loadaddr} twrp.img; then
  echo twrp loaded, booting...
  bootm ${loadaddr}
else
  echo ERROR: twrp.img not found on usb
fi
""",
    # 3) 把 U 盘里的 TWRP 写入 recovery 分区再引导 (store write 分区名 地址 偏移 大小)
    "install.script": """\
echo === USB INSTALL: write TWRP to recovery partition ===
if fatload usb 0 ${loadaddr} twrp.img; then
  store write recovery ${loadaddr} 0 ${filesize}
  echo recovery partition written, booting twrp...
  bootm ${loadaddr}
else
  echo ERROR: twrp.img not found on usb
fi
""",
    # 4) 极限救援: 同时写 boot 分区 (U 盘里放打补丁的 boot.img) 再引导 TWRP
    "rescue_boot.script": """\
echo === USB EXTREME RESCUE ===
if fatload usb 0 ${loadaddr} boot_rescue.img; then
  store write boot ${loadaddr} 0 ${filesize}
  echo boot partition written
else
  echo WARN: boot_rescue.img not found, skip
fi
if fatload usb 0 ${loadaddr} twrp.img; then
  bootm ${loadaddr}
else
  echo no twrp.img, reset
  reset
fi
""",
}


def main():
    ap = argparse.ArgumentParser(description="U-Boot legacy script 打包器")
    ap.add_argument("--text", help="脚本文本文件")
    ap.add_argument("--out", help="输出镜像路径")
    ap.add_argument("--name", default="usb_rescue", help="镜像 name 字段(<=32B)")
    ap.add_argument("--demo", action="store_true", help="生成全部标准脚本")
    ap.add_argument("--outdir", default=".", help="demo 输出目录")
    a = ap.parse_args()

    if a.demo:
        import os
        os.makedirs(a.outdir, exist_ok=True)
        for fn, text in SCRIPTS.items():
            blob = build_script_image(text, fn.split(".")[0].encode())
            out = os.path.join(a.outdir, fn.replace(".script", "") + "_autoscript")
            open(out, "wb").write(blob)
            print(f"=== {out} ({len(blob)}B) ===")
            if not verify_image(blob):
                sys.exit("自检失败: " + out)
        # 同时把明文脚本也放出来便于审阅
        for fn, text in SCRIPTS.items():
            open(os.path.join(a.outdir, fn), "w", newline="\n").write(text)
        print("全部生成并自检通过")
        return

    if not a.text or not a.out:
        ap.error("需要 --text 与 --out, 或 --demo")
    text = open(a.text, encoding="utf-8").read()
    blob = build_script_image(text, a.name.encode())
    open(a.out, "wb").write(blob)
    print(f"生成 {a.out} ({len(blob)}B)")
    if not verify_image(blob):
        sys.exit("自检失败")


if __name__ == "__main__":
    main()
