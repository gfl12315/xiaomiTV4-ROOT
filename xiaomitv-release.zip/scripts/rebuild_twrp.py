# -*- coding: utf-8 -*-
"""
rebuild_twrp.py <twrp.img>

TWRP 补丁流水线：把 TWRP ramdisk 里的 systemcontrol_static（sbin/ 和 twrp/sbin/
下的同名文件，Amlogic ubootenv 管理工具）替换为空脚本。

为什么必须打补丁：
  TWRP 会话期间 systemcontrol_static 会加载 env 属性并把官方默认值写回 env 分区，
  导致 env 里的 androidboot.selinux=permissive 被抹掉、root 持久化被破坏。
  实测：未打补丁的 TWRP 进出一次，env 即被改回 enforcing；打补丁后进出 TWRP
  env 保持不变。

输出 twrp_patched.img，含解包自检。TWRP 其余功能不受影响。
"""
import struct, gzip, hashlib, sys

src = sys.argv[1]
img = open(src, 'rb').read()
assert img[:8] == b'ANDROID!', '非 Android boot 镜像'

ks = struct.unpack('<I', img[8:12])[0]      # kernel size
ds = struct.unpack('<I', img[16:20])[0]     # ramdisk size
ss = struct.unpack('<I', img[32:36])[0]     # second size
ps = struct.unpack('<I', img[36:40])[0]     # page size
k_pages = (ks + ps - 1) // ps
rd_off  = 2048 + k_pages * ps
sec_off = rd_off + (ds + ps - 1) // ps * ps
kernel  = img[2048:2048 + ks]
second  = img[sec_off:sec_off + ss] if ss else b''

# ---- 1. 解压 ramdisk ----
rd = img[rd_off:rd_off + ds]
if rd[:2] == b'\x1f\x8b':
    rd = gzip.decompress(rd)
print('ramdisk(cpio): %d 字节' % len(rd))

# ---- 2. 解析 cpio (newc 格式) ----
d = rd
off, entries = 0, []
while off < len(d):
    if d[off:off+6] != b'070701':
        t = d.find(b'070701', off)
        if t == -1:
            break
        off = t
        continue
    f = [int(d[off+6+i*8:off+14+i*8], 16) for i in range(13)]
    mode, uid, gid = f[1], f[2], f[3]
    namesize, filesize = f[11], f[6]
    name = d[off+110:off+110+namesize-1].decode('latin1')
    data_off = (off + 110 + namesize + 3) & ~3
    data = d[data_off:data_off + filesize]
    if name == 'TRAILER!!!':
        break
    entries.append((name, mode, uid, gid, data))
    off = data_off + filesize
    off = (off + 3) & ~3
print('cpio 条目数: %d' % len(entries))

# ---- 3. 中性化 systemcontrol_static ----
NOOP = b'#!/system/bin/sh\n# systemcontrol disabled: prevent ubootenv overwrite\nexit 0\n'
patched = 0
for i, (name, mode, uid, gid, data) in enumerate(entries):
    if name.endswith('systemcontrol_static'):
        entries[i] = (name, 0o100750, uid, gid, NOOP)
        patched += 1
        print('替换: %s' % name)
if patched == 0:
    sys.exit('未找到 systemcontrol_static —— 该镜像无需补丁或结构不同，停止')

# ---- 4. 重建 cpio ----
def pad4(b):
    return b + b'\x00' * ((4 - len(b) % 4) % 4)

out_cpio = b''
for name, mode, uid, gid, data in entries:
    nb = name.encode('latin1') + b'\x00'
    hdr = b'070701' + ''.join('%08X' % v for v in
          [0, mode, uid, gid, 1, 0, len(data), 0, 0, 0, 0, len(nb), 0]).encode()
    out_cpio = pad4(out_cpio + hdr + nb)
    out_cpio = pad4(out_cpio + data)
hdr = b'070701' + ''.join('%08X' % v for v in [0,0,0,0,1,0,0,0,0,0,0,11,0]).encode()
out_cpio = pad4(out_cpio + hdr + b'TRAILER!!!\x00')
out_cpio += b'\x00' * ((len(out_cpio) + 511) // 512 * 512 - len(out_cpio))
print('新 cpio: %d 字节' % len(out_cpio))

# ---- 5. 重打包 boot 镜像（严格页对齐）----
new_rd = gzip.compress(out_cpio, 6)
rd_pad = (ps - len(new_rd) % ps) % ps
header = bytearray(img[:2048])
header[16:20] = struct.pack('<I', len(new_rd))
h = hashlib.sha1()
h.update(kernel); h.update(new_rd); h.update(second)
header[40:48] = h.digest()[:8]

out = bytes(header) + kernel + b'\x00' * (k_pages*ps - ks) + new_rd + b'\x00'*rd_pad + second
print('输出 twrp_patched.img: %d 字节 (原 %d)' % (len(out), len(img)))
if len(out) > 16 * 1024 * 1024:
    sys.exit('超出 recovery 分区 16MB!')
open('twrp_patched.img', 'wb').write(out)

# ---- 6. 自检：重新解包验证补丁已写入 ----
d2 = open('twrp_patched.img', 'rb').read()
ds2 = struct.unpack('<I', d2[16:20])[0]
rd2 = d2[rd_off:rd_off + ds2]
if rd2[:2] == b'\x1f\x8b':
    rd2 = gzip.decompress(rd2)
assert b'systemcontrol disabled' in rd2, '自检失败: 补丁未写入 ramdisk'
print('自检通过: systemcontrol_static 已替换为空脚本')
