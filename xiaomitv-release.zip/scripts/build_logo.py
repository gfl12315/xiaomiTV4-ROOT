#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_logo.py — 小米电视4 (AML_RES! V2) 开机 logo 重打包工具

格式依据 U-Boot cmd_imgread.c（Amlogic txl 平台源码）：
  镜像头 AmlResImgHead_t 64B: crc(version 前4B, V2 不校验) / version=2 /
         magic "AML_RES!" / imgSz / imgItemNum / alignSz=16
  条目头 AmlResItemHead_t 64B pack(1):
         magic=0x27051956 / hcrc / size / start / end / next / dcrc /
         index,nums,type,comp / name[32]
  条目数据 = gzip(bmp24bpp)，U-Boot 只校验头与条目 magic，CRC 字段不校验。
  请求 "bootup" 时按 outputmode 纠正为 bootup_720/bootup_1080，
  找不到时回退原始名 bootup —— 本脚本六名全覆盖，任何路径都命中。

原厂规格实测（本机型 logo.img 备份测量）：
  1080p: 1920x1080, 图标 142x142 居中
  720p : 1280x720,  图标 96x96  居中

用法:
  python build_logo.py --src icon.png --out logo.img [--icon-1080 142 --icon-720 96]
"""
import argparse
import gzip
import io
import struct
import sys

try:
    from PIL import Image
except ImportError:
    sys.exit("需要 Pillow: pip install pillow")

import numpy as np


def encode_bmp24(canvas):
    """RGB 图 → 24bpp BMP 字节（自底向上、BGR、行 4 字节对齐）。"""
    w, h = canvas.size
    a = np.asarray(canvas, dtype=np.uint8)          # (h, w, 3) RGB
    bgr = a[:, :, ::-1]                             # → BGR
    row_sz = (w * 3 + 3) // 4 * 4
    pad = row_sz - w * 3
    rows = [bgr[y].tobytes() for y in range(h)]     # 自底向上时再反转
    data = b"".join(rows[::-1])
    padb = b"\x00" * pad
    if pad:
        data = b"".join(rows[y].tobytes() + padb for y in range(h - 1, -1, -1))
    fsz = 54 + row_sz * h
    hdr = struct.pack(
        "<2sIHHIIIiHHIIiiII",
        b"BM", fsz, 0, 0, 54,
        40, w, h, 1, 24, 0, row_sz * h, 2835, 2835, 0, 0,
    )
    assert len(hdr) == 54
    return hdr + data

IH_MAGIC = 0x27051956
RES_MAGIC = b"AML_RES!"
ALIGN = 16          # 镜头头 alignSz 字段
DATA_ALIGN = 0x800  # 条目数据 2K 对齐（mtd nand 页），emmc 512 也兼容

# 六条目 → 分辨率映射。
# 顺序关键：U-Boot 匹配规则是 `picName==name || 原始请求名==name`，
# 遍历按表序，原始名 fallback 会提前命中，因此精确名必须排在 bootup 之前。
# 请求链（cmd_imgread.c）: bootup + outputmode[720/576/480]→bootup_720，否则→bootup_1080。
ITEMS = [
    ("bootup_1080",  "1080"),   # 1080p 电视开机首选
    ("bootup_720",   "720"),    # 720p 模式
    ("bootup",       "720"),    # 原始名兜底（env 缺失时）
    ("bootup_1920",  "1080"),   # 部分固件直呼此名
    ("redmi_1920",   "1080"),
    ("redmi",        "720"),
]


def make_bmp(canvas_w, canvas_h, icon_img, icon_size):
    """黑底 24bpp BMP，中央贴图标。返回 BMP 字节。"""
    # 原图带透明通道则保留圆角；不带则整块贴
    icon = icon_img.convert("RGBA")
    if icon.width != icon_size or icon.height != icon_size:
        icon = icon.resize((icon_size, icon_size), Image.LANCZOS)
    canvas = Image.new("RGB", (canvas_w, canvas_h), (0, 0, 0))
    x = (canvas_w - icon_size) // 2
    y = (canvas_h - icon_size) // 2
    canvas.paste(icon, (x, y), icon)  # 用自身 alpha 作 mask
    return encode_bmp24(canvas)


def pack_res_img(bmp720_bytes, bmp1080_bytes):
    """组 AML_RES! V2 镜像。返回镜像字节与条目信息表。"""
    gz = {}
    for res in ("720", "1080"):
        raw = bmp720_bytes if res == "720" else bmp1080_bytes
        # mtime=0: 相同输入产出相同字节，可复现
        gz[res] = gzip.compress(raw, compresslevel=9, mtime=0)

    head_sz = 64
    table_sz = head_sz + len(ITEMS) * 64
    # 数据区起点：条目表之后 2K 对齐
    data_off = (table_sz + DATA_ALIGN - 1) // DATA_ALIGN * DATA_ALIGN

    blob = bytearray(b"\x00" * data_off)
    cur = data_off
    infos = []
    for name, res in ITEMS:
        d = gz[res]
        blob += b"\x00" * (cur - len(blob))          # 补对齐空隙
        blob += d
        infos.append((name, res, len(d), cur))
        cur += len(d)
        cur = (cur + DATA_ALIGN - 1) // DATA_ALIGN * DATA_ALIGN

    img_sz = len(blob)

    # 镜像头 64B（pack(4)）：crc / version / magic[8] / imgSz / itemNum / alignSz / reserv
    head = struct.pack("<Ii8sIII", 0, 2, RES_MAGIC, img_sz, len(ITEMS), ALIGN)
    head += b"\x00" * (64 - len(head))
    blob[0:64] = head

    # 条目表（字段惯例照抄原厂: next=下一条偏移/末条0, nums=条目总数, idx=序号）
    n_items = len(infos)
    for i, (name, res, size, start) in enumerate(infos):
        nxt = (64 + (i + 1) * 64) if i < n_items - 1 else 0
        e = struct.pack(
            "<IIIIIIIBBBB", IH_MAGIC, 0, size, start, 0, nxt, 0, i, n_items, 0, 0
        )
        nm = name.encode("ascii")
        e += nm + b"\x00" * (32 - len(nm))          # name[32]
        assert len(e) == 64, len(e)
        blob[64 + i * 64: 64 + (i + 1) * 64] = e

    return bytes(blob), infos


def verify(img_bytes):
    """回读自检：头、每个条目、gunzip、BMP 头、中心像素。"""
    ok = True
    crc, ver = struct.unpack("<Ii", img_bytes[0:8])
    magic = img_bytes[8:16]
    img_sz, item_num, align_sz = struct.unpack("<III", img_bytes[16:28])
    assert magic == RES_MAGIC and ver == 2, "镜像头不合法"
    assert img_sz == len(img_bytes), f"imgSz {img_sz} != 实际 {len(img_bytes)}"
    assert align_sz == ALIGN, "alignSz 不合法"
    print(f"[自检] 头 OK: imgSz={img_sz} items={item_num}")

    for i in range(item_num):
        e = img_bytes[64 + i * 64: 64 + (i + 1) * 64]
        m, _, size, start = struct.unpack("<IIII", e[0:16])
        name = e[32:64].split(b"\x00")[0].decode()
        assert m == IH_MAGIC, f"条目{name} magic 错"
        chunk = img_bytes[start:start + size]
        assert chunk[:2] == b"\x1f\x8b", f"条目{name} 数据不是 gzip"
        bmp = gzip.decompress(chunk)
        w, h = struct.unpack("<ii", bmp[18:26])
        bpp = struct.unpack("<H", bmp[28:30])[0]
        cx, cy = w // 2, h // 2
        row_sz = ((w * 3 + 3) // 4) * 4
        off = 54 + (h - 1 - cy) * row_sz + cx * 3   # BMP 自底向上
        r, g, b = bmp[off + 2], bmp[off + 1], bmp[off]
        bright = r + g + b
        status = "OK" if bright > 60 else "中心疑似黑!"  # 图标应为白底非黑
        if bright <= 60:
            ok = False
        print(f"[自检] {name:12s} {w}x{h} bpp={bpp} 中心亮度={bright} [{status}]")
    return ok


def main():
    ap = argparse.ArgumentParser(description="AML_RES! V2 logo 打包")
    ap.add_argument("--src", required=True, help="源 PNG/JPG 图标")
    ap.add_argument("--out", required=True, help="输出 logo 镜像路径")
    ap.add_argument("--icon-1080", type=int, default=142, help="1080p 图标边长(原厂142)")
    ap.add_argument("--icon-720", type=int, default=96, help="720p 图标边长(原厂96)")
    a = ap.parse_args()

    icon = Image.open(a.src)
    print(f"源图: {a.src} {icon.size} mode={icon.mode}")

    bmp1080 = make_bmp(1920, 1080, icon, a.icon_1080)
    bmp720 = make_bmp(1280, 720, icon, a.icon_720)
    blob, infos = pack_res_img(bmp720, bmp1080)
    open(a.out, "wb").write(blob)
    print(f"打包完成: {a.out} ({len(blob)} 字节)")
    for name, res, size, start in infos:
        print(f"  条目 {name:12s} {res}p  gzip={size:6d}  start=0x{start:x}")

    if not verify(open(a.out, "rb").read()):
        sys.exit("自检发现异常，请检查")
    print("[自检] 全部通过")


if __name__ == "__main__":
    main()
