#!/system/bin/sh
# share.sh — 按需临时文件服务器 (需 root 跑: su -c 'sh /data/local/tmp/share.sh [目录|off]')
# 开门: sh share.sh /sdcard/Download   → 浏览器 http://TV_IP:8081 下载该目录
#       sh share.sh (无参数默认 /sdcard)
# 关门: sh share.sh off
P=8081

case "$1" in
  off)
    for p in /proc/[0-9]*; do
      C=$(tr '\0' ' ' < $p/cmdline 2>/dev/null)
      case "$C" in
        /data/local/tmp/httpd*$P*) kill ${p#/proc/} 2>/dev/null && echo "closed: killed ${p#/proc/}" ;;
      esac
    done
    echo "8081 已关门"
    ;;
  "")
    DIR=/sdcard
    ;;
  *)
    DIR=$1
    ;;
esac

if [ "$1" != "off" ]; then
  # 先清旧的临时实例
  for p in /proc/[0-9]*; do
    C=$(tr '\0' ' ' < $p/cmdline 2>/dev/null)
    case "$C" in
      /data/local/tmp/httpd*$P*) kill ${p#/proc/} 2>/dev/null ;;
    esac
  done
  sleep 1
  /data/local/tmp/httpd $P $DIR >/dev/null 2>&1 &
  sleep 1
  if netstat -tln | grep -q ":$P "; then
    echo "临时文件服务已开: http://<TV_IP>:$P  (docroot=$DIR)"
    echo "用完请关门: su -c 'sh /data/local/tmp/share.sh off'"
    echo "提示: 8081 无认证, 仅临时使用, 用完即关!"
  else
    echo "启动失败"
  fi
fi
