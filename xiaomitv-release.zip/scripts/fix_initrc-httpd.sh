#!/system/bin/sh
# fix_initrc.sh — init.rc 的 httpd 服务 docroot 收紧: /sdcard → /data/adb/www
# 步骤: 备份 → remount rw → awk 重写 → remount ro → 杀服务让 init 自动重启
set -e

echo "---1 备份---"
cp /init.rc /data/adb/init.rc.bak_httpd
ls -la /data/adb/init.rc.bak_httpd

echo "---2 remount rw---"
mount -o remount,rw / && echo remount-ok

echo "---3 awk 重写 (仅 service httpd 行)---"
awk '{
  if ($0 ~ /^service httpd \/data\/local\/tmp\/httpd 8080 \/sdcard/)
    print "service httpd /data/local/tmp/httpd 8080 /data/adb/www";
  else
    print;
}' /init.rc > /init.rc.new
echo "diff check:"
grep -n "service httpd" /init.rc.new
cmp -s /init.rc /init.rc.new && echo "NO CHANGE - ABORT" || echo "changed OK"
mv /init.rc.new /init.rc

echo "---4 remount ro---"
mount -o remount,ro / && echo remount-ro-ok

echo "---5 杀 httpd, init 自动重启带新参数---"
for p in /proc/[0-9]*; do
  C=$(tr '\0' ' ' < $p/cmdline 2>/dev/null)
  case "$C" in
    /data/local/tmp/httpd*) kill ${p#/proc/} 2>/dev/null && echo "killed ${p#/proc/}" ;;
  esac
done
echo "---done, wait init respawn---"
