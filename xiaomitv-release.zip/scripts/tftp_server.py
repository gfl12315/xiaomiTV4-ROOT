#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""tftp_server.py — 电脑侧 TFTP 服务器 (U-Boot tftpboot 下载用)
用法: python tftp_server.py   (root 目录 = 同目录 tftp_root/, 端口 69/UDP)
依赖: pip install tftpy
文件: 把要给电视的固件/测试文件放 tftp_root/ 下 (如 test8m.bin / boot.img)
"""
import os, sys
try:
    import tftpy
except ImportError:
    sys.exit("需要 tftpy: pip install tftpy")

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tftp_root")
os.makedirs(ROOT, exist_ok=True)
print(f"TFTP root: {ROOT}")
print(f"目录内文件: {os.listdir(ROOT)}")
print("监听 0.0.0.0:69/UDP — 电视 U-Boot tftpboot 将从这里下载 (Ctrl+C 停止)")
server = tftpy.TftpServer(ROOT)
try:
    server.listen()
except KeyboardInterrupt:
    server.stop()
