/* httpd.c - minimal static file server for the xmen TV (armv7 static, musl)
 * Usage: httpd <port> <docroot>
 * Features: GET only, dir listing, .. rejection, %xx url decode
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <dirent.h>
#include <sys/stat.h>

static void url_decode(char *s) {
    char *w = s;
    for (; *s; s++) {
        if (*s == '%' && s[1] && s[2]) {
            char h[3] = { s[1], s[2], 0 };
            *w++ = (char)strtol(h, NULL, 16);
            s += 2;
        } else if (*s == '+') {
            *w++ = ' ';
        } else {
            *w++ = *s;
        }
    }
    *w = 0;
}

static void html_escape(const char *in, char *out, size_t n) {
    size_t j = 0;
    for (size_t i = 0; in[i] && j + 8 < n; i++) {
        if (in[i] == '<') { memcpy(out+j, "&lt;", 4); j += 4; }
        else if (in[i] == '>') { memcpy(out+j, "&gt;", 4); j += 4; }
        else if (in[i] == '&') { memcpy(out+j, "&amp;", 5); j += 5; }
        else out[j++] = in[i];
    }
    out[j] = 0;
}

static void href_encode(const char *in, char *out, size_t n) {
    size_t j = 0;
    for (size_t i = 0; in[i] && j + 4 < n; i++) {
        unsigned char c = (unsigned char)in[i];
        if (c == ' ' || c == '%' || c == '"' || c == '#' || c == '?' ||
            (c > 0 && c < 32)) {
            j += snprintf(out+j, n-j, "%%%02X", c);
        } else {
            out[j++] = (char)c;
        }
    }
    out[j] = 0;
}

static const char *ctype(const char *p) {
    const char *e = strrchr(p, '.');
    if (!e) return "application/octet-stream";
    if (!strcmp(e, ".html") || !strcmp(e, ".htm")) return "text/html";
    if (!strcmp(e, ".css")) return "text/css";
    if (!strcmp(e, ".json")) return "application/json";
    if (!strcmp(e, ".js"))  return "text/javascript";
    if (!strcmp(e, ".txt") || !strcmp(e, ".log") || !strcmp(e, ".prop")) return "text/plain";
    if (!strcmp(e, ".png")) return "image/png";
    if (!strcmp(e, ".jpg") || !strcmp(e, ".jpeg")) return "image/jpeg";
    if (!strcmp(e, ".gif")) return "image/gif";
    if (!strcmp(e, ".mp4")) return "video/mp4";
    if (!strcmp(e, ".apk")) return "application/vnd.android.package-archive";
    return "application/octet-stream";
}

int main(int argc, char **argv) {
    int port = argc > 1 ? atoi(argv[1]) : 8080;
    /* docroot 安全策略: 默认写死 /data/adb/www; 仅拦 /sdcard 整盘 (裸奔洞),
     * 子目录 (/sdcard/Download 等) 与其他路径放行 — share.sh 临时开门用 */
    const char *root = "/data/adb/www";
    if (argc > 2 && strcmp(argv[2], "/sdcard") != 0)
        root = argv[2];

    int s = socket(AF_INET, SOCK_STREAM, 0);
    int one = 1;
    setsockopt(s, SOL_SOCKET, SO_REUSEADDR, &one, 4);
    struct sockaddr_in a;
    memset(&a, 0, sizeof a);
    a.sin_family = AF_INET;
    a.sin_addr.s_addr = INADDR_ANY;
    a.sin_port = htons((unsigned short)port);
    if (bind(s, (struct sockaddr *)&a, sizeof a) < 0) { perror("bind"); return 1; }
    listen(s, 8);

    char req[4096], path[1024];
    for (;;) {
        int c = accept(s, 0, 0);
        if (c < 0) continue;
        int n = read(c, req, sizeof req - 1);
        if (n <= 0) { close(c); continue; }
        req[n] = 0;
        if (strncmp(req, "GET ", 4)) { close(c); continue; }
        char *p = req + 4;
        char *e = strchr(p, ' ');
        if (!e) { close(c); continue; }
        *e = 0;
        url_decode(p);
        if (strstr(p, "..")) {   /* path traversal: reject */
            write(c, "HTTP/1.0 403 Forbidden\r\nConnection: close\r\n\r\n", 45);
            close(c); continue;
        }
        if (p[strlen(p)-1] == '/') p[strlen(p)-1] = 0;   /* normalize */
        snprintf(path, sizeof path, "%s%s", root, p[0] ? p : "/");

        struct stat st;
        if (stat(path, &st) == 0 && S_ISDIR(st.st_mode)) {
            DIR *dd = opendir(path);
            if (!dd) {
                write(c, "HTTP/1.0 404 Not Found\r\nConnection: close\r\n\r\n", 45);
                close(c); continue;
            }
            char body[131072];
            int bi = snprintf(body, sizeof body,
                "<html><head><meta charset=\"utf-8\"><title>Index %s</title></head>"
                "<body><h2>%s</h2><hr><pre>", p, p);
            struct dirent *de;
            char esc[512], href[512];
            while ((de = readdir(dd))) {
                if (!strcmp(de->d_name, ".")) continue;
                char full[1200];
                snprintf(full, sizeof full, "%s/%s", path, de->d_name);
                struct stat s2;
                int isdir = (stat(full, &s2) == 0 && S_ISDIR(s2.st_mode));
                html_escape(de->d_name, esc, sizeof esc);
                char rel[600];
                snprintf(rel, sizeof rel, "%s/%s", p, de->d_name);
                href_encode(rel, href, sizeof href);
                bi += snprintf(body+bi, sizeof body-bi,
                    "<a href=\"%s%s\">%-48s %s</a><br>",
                    href, isdir ? "/" : "", esc, isdir ? "[DIR]" : "");
                if (bi > (int)sizeof body - 2048) break;
            }
            closedir(dd);
            bi += snprintf(body+bi, sizeof body-bi, "</pre><hr>httpd for xmen</body></html>");
            char hdr[192];
            int hl = snprintf(hdr, sizeof hdr,
                "HTTP/1.0 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                "Content-Length: %d\r\nConnection: close\r\n\r\n", bi);
            write(c, hdr, hl);
            write(c, body, bi);
        } else {
            FILE *f = fopen(path, "rb");
            if (!f) {
                write(c, "HTTP/1.0 404 Not Found\r\nConnection: close\r\n\r\n", 45);
                close(c); continue;
            }
            fseek(f, 0, SEEK_END);
            long sz = ftell(f);
            fseek(f, 0, SEEK_SET);
            char hdr[256];
            int hl = snprintf(hdr, sizeof hdr,
                "HTTP/1.0 200 OK\r\nContent-Type: %s\r\nContent-Length: %ld\r\n"
                "Connection: close\r\n\r\n", ctype(path), sz);
            write(c, hdr, hl);
            char buf[16384];
            size_t r;
            while ((r = fread(buf, 1, sizeof buf, f)) > 0) {
                if (write(c, buf, r) < 0) break;
            }
            fclose(f);
        }
        close(c);
    }
    return 0;
}
