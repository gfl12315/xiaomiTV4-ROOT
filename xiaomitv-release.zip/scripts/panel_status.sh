#!/system/bin/sh
# panel_status.sh v2 — 采集电视状态写 status.json (awk-only, 无 sed 依赖)
# 由 kcrontab 每 60s 调用; 原子写(tmp+mv)防半截 JSON
W=/data/adb/www
T=$W/status.json.tmp
O=$W/status.json

# ---- 内核模块 (grep -c 输出 0/1, 无 -q 管道问题) ----
MK=$(lsmod 2>/dev/null | grep -c "^kctl ")
MA=$(lsmod 2>/dev/null | grep -c "^kadblock ")
MC=$(lsmod 2>/dev/null | grep -c "^kcrontab ")
MP=$(lsmod 2>/dev/null | grep -c "^kcap ")
MW=$(lsmod 2>/dev/null | grep -c "^kwatch ")

# ---- kadblock 数字: 一条 awk 拆全部字段 ----
set -- $(awk '/^kadblock stats/{
  split($0, a, " ");
  r=0; d=0; p=0; u=0;
  for (i in a) { split(a[i], b, "=");
    if (b[1]=="raw") r=b[2]+0;
    if (b[1]=="dns_total") d=b[2]+0;
    if (b[1]=="dropped") p=b[2]+0;
    if (b[1]=="rules") u=b[2]+0; }
  print r+0, d+0, p+0, u+0;
  exit;
}' /proc/kadblock 2>/dev/null)
KB_RAW=${1:-0}; KB_DNS=${2:-0}; KB_DROP=${3:-0}; KB_RULES=${4:-0}

# ---- kcrontab: tick/execs/fails ----
set -- $(awk '/^kcrontab: tick=/{
  split($0, a, " ");
  t=0; e=0; f=0;
  for (i in a) { split(a[i], b, "=");
    if (b[1]=="tick") t=b[2]+0;
    if (b[1]=="execs") e=b[2]+0;
    if (b[1]=="fails") f=b[2]+0; }
  print t+0, e+0, f+0;
  exit;
}' /proc/kcrontab 2>/dev/null)
KC_TICK=${1:-0}; KC_EXEC=${2:-0}; KC_FAIL=${3:-0}

# ---- kwatch: checks/violations/heal ----
set -- $(awk '/^kwatch: sct@/{
  split($0, a, " ");
  c=0; v=0; h=0;
  for (i in a) { split(a[i], b, "=");
    if (b[1]=="checks") c=b[2]+0;
    if (b[1]=="violations") v=b[2]+0;
    if (b[1]=="heal") h=b[2]+0; }
  print c+0, v+0, h+0;
  exit;
}' /proc/kwatch 2>/dev/null)
KW_CHK=${1:-0}; KW_VIO=${2:-0}; KW_HEAL=${3:-0}

# ---- 端口 (grep -c) ----
A=$(netstat -tln 2>/dev/null | grep -c ":5555 ")
H=$(netstat -tln 2>/dev/null | grep -c ":8080 ")
S=$(netstat -tln 2>/dev/null | grep -c ":22 ")

# ---- 系统 ----
UPS=$(cut -d' ' -f1 /proc/uptime | cut -d. -f1)
MEMA=$(grep MemAvailable /proc/meminfo | awk '{print $2+0}')
LOAD=$(cut -d' ' -f1 /proc/loadavg)
TEMP=$(cat /sys/devices/virtual/thermal/thermal_zone0/temp 2>/dev/null)
case "$TEMP" in ''|*[!0-9]*) TEMP=0 ;; esac
D=$(ANDROID_DATA=/data TZ=CST-8 date "+%Y-%m-%d %H:%M:%S")

printf '{"time":"%s","uptime_s":%s,"mem_free_kb":%s,"load":"%s","temp_c":%s,"adb":%s,"http":%s,"ssh":%s,"kctl":%s,"kadblock":%s,"kcrontab":%s,"kcap":%s,"kwatch":%s,"kb_raw":%s,"kb_dns":%s,"kb_dropped":%s,"kb_rules":%s,"kc_tick":%s,"kc_execs":%s,"kc_fails":%s,"kw_checks":%s,"kw_violations":%s,"kw_heal":%s}\n' \
  "$D" "${UPS:-0}" "${MEMA:-0}" "${LOAD:-0}" "$TEMP" \
  "${A:-0}" "${H:-0}" "${S:-0}" \
  "${MK:-0}" "${MA:-0}" "${MC:-0}" "${MP:-0}" "${MW:-0}" \
  "$KB_RAW" "$KB_DNS" "$KB_DROP" "$KB_RULES" \
  "$KC_TICK" "$KC_EXEC" "$KC_FAIL" "$KW_CHK" "$KW_VIO" "$KW_HEAL" > $T

sync
mv $T $O 2>/dev/null || cp $T $O
chmod 644 $O 2>/dev/null
