#!/system/bin/sh
# BCB 守卫: misc 分区 command 字段被写(OTA 安装前奏)即清零+记录
# 开关: /data/local/tmp/bcb_guard_off 存在时跳过(自己用 BCB 安装时创建此文件)
[ -f /data/local/tmp/bcb_guard_off ] && exit 0
H=$(dd if=/dev/block/misc bs=32 count=1 2>/dev/null | md5sum | cut -d' ' -f1)
Z=$(dd if=/dev/zero bs=32 count=1 2>/dev/null | md5sum | cut -d' ' -f1)
if [ "$H" != "$Z" ]; then
  echo "$(date) BCB被写入($H) 已清零拦截" >> /data/local/tmp/bcb_guard.log
  dd if=/dev/zero of=/dev/block/misc bs=32 count=1 2>/dev/null
  sync
fi
