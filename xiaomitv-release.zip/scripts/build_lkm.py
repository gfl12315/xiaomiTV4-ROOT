#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_lkm.py — 无内核源码/头文件的手工 .ko 组装器（AArch64, kernel 3.14 txl_xmen）

原理: 模块 .ko 就是带 modinfo/this_module 特节的 ELF 可重定位对象。
  1. 交叉编译器(-c)把模块 C 代码编成普通 .o（extern printk 等内核符号为 UND）;
  2. 本脚本从 .o 挑代码/数据/重定位节, 补齐 .modinfo 与 .gnu.linkonce.this_module,
     重映射符号表节索引, 组装成 insmod 可解析的 .ko。

实测参数(设备 cfg80211.ko 解析 + kallsyms + U-Boot 源码):
  vermagic            = "3.14.29 SMP preempt mod_unload aarch64"
  sizeof(struct module) = 536
  name 偏移 = 24, init 指针偏移 = 296, exit 指针偏移 = 520
  MODVERSIONS = 关(无 __crc_*), MODULE_SIG = 关(kallsyms 无签名符号)

用法:
  zig cc -target aarch64-linux-none -c -O2 -g0 -fno-PIE mod.c -o mod.o
  python build_lkm.py mod.o 模块名 输出.ko
"""
import struct
import sys

VERMAGIC = "3.14.29 SMP preempt mod_unload aarch64"
MOD_STRUCT_SIZE = 536
MOD_NAME_OFF = 24
MOD_INIT_OFF = 296
MOD_EXIT_OFF = 520
R_AARCH64_ABS64 = 257

SHT_PROGBITS, SHT_SYMTAB, SHT_STRTAB, SHT_RELA, SHT_NOBITS = 1, 2, 3, 4, 8
SHF_WRITE, SHF_ALLOC, SHF_EXECINSTR = 0x1, 0x2, 0x4
SHN_UNDEF, SHN_ABS = 0, 0xFFF1
KEEP = {'.text', '.rodata', '.data', '.bss', '.rodata.str1.1', '.rodata.str1.8',
        '.rodata.cst1', '.rodata.cst4', '.rodata.cst8', '.rodata.cst16'}
KEEP_RELA = {'.rela.' + n[1:] for n in KEEP}


def parse_elf(d):
    assert d[:4] == b'\x7fELF' and d[4] == 2 and d[5] == 1, '需要 ELF64 LE'
    assert struct.unpack('<H', d[18:20])[0] == 183, '需要 AArch64'
    e_shoff = struct.unpack('<Q', d[40:48])[0]
    entsz, num, strx = struct.unpack('<HHH', d[58:64])
    secs = []
    for i in range(num):
        o = e_shoff + i * entsz
        name, typ, flags, addr, offset, size, link, info, align, esz = struct.unpack(
            '<IIQQQQIIQQ', d[o:o + 64])
        secs.append({'idx': i, 'name_off': name, 'name': '', 'type': typ, 'flags': flags,
                     'off': offset, 'size': size, 'link': link, 'info': info,
                     'align': max(align, 1), 'entsz': esz})
    so = secs[strx]['off']
    for s in secs:
        e = d.index(b'\x00', so + s['name_off'])
        s['name'] = d[so + s['name_off']:e].decode()
    return secs


def load_obj(obj_path):
    d = open(obj_path, 'rb').read()
    secs = parse_elf(d)
    strtab_off = None
    symtab = None
    for s in secs:
        if s['name'] == '.strtab':
            strtab_off = s['off']
        if s['name'] == '.symtab':
            symtab = s
    syms = []
    for i in range(symtab['size'] // 24):
        o = symtab['off'] + i * 24
        name, info, other, shndx, value, size = struct.unpack('<IBBHQQ', d[o:o + 24])
        e = d.index(b'\x00', strtab_off + name)
        syms.append({'idx': i, 'name': d[strtab_off + name:e].decode(),
                     'info': info, 'other': other, 'shndx': shndx,
                     'value': value, 'size': size})
    relas = {}
    for s in secs:
        if s['type'] == SHT_RELA:
            items = []
            for j in range(s['size'] // 24):
                o = s['off'] + j * 24
                ro, ri, ra = struct.unpack('<QQq', d[o:o + 24])
                items.append((ro, ri >> 32, ri & 0xFFFFFFFF, ra))
            relas[s['info']] = items     # key = 被重定位节旧索引
    return d, secs, syms, relas


def build_ko(obj_path, modname, out_path):
    d, secs, syms, relas = load_obj(obj_path)

    # ---------- 新节列表 ----------
    secs_out = []
    old2new = {}
    symtab_idx = strtab_idx = this_idx = None

    def push(name, typ, flags, align, data, size=None, link=0, info=0, entsz=0):
        """size: 对 SHT_NOBITS 必须传 .o 节头的真实 size（内核按它分配内存）"""
        secs_out.append({'name': name, 'type': typ, 'flags': flags, 'align': max(align, 1),
                         'data': bytearray(data),
                         'size': size if size is not None else len(data),
                         'link': link, 'info': info, 'entsz': entsz})
        return len(secs_out) - 1

    push('', 0, 0, 0, b'', size=0)                                  # [0] NULL

    # 代码/数据节
    for s in secs:
        if s['name'] in KEEP and s['type'] != SHT_RELA:
            data = d[s['off']:s['off'] + s['size']] if s['type'] != SHT_NOBITS else b''
            ni = push(s['name'], s['type'], s['flags'], s['align'], data, size=s['size'])
            old2new[s['idx']] = ni

    # .modinfo
    push('.modinfo', SHT_PROGBITS, SHF_ALLOC | SHF_WRITE, 1,
         ('license=GPL\x00vermagic=' + VERMAGIC + '\x00').encode())

    # this_module（536B: name@24, init/exit 槽由重定位填充）
    tm = bytearray(MOD_STRUCT_SIZE)
    nmb = modname.encode()[:63]
    tm[MOD_NAME_OFF:MOD_NAME_OFF + len(nmb)] = nmb
    this_idx = push('.gnu.linkonce.this_module', SHT_PROGBITS, SHF_ALLOC | SHF_WRITE,
                    8, bytes(tm))

    # ---------- 符号引用闭包过滤 ----------
    referenced = {0}
    keep_names = ('init_module', 'cleanup_module')
    sym_old_by_name = {}
    for s in syms:
        if s['name'] in keep_names:
            referenced.add(s['idx'])
            sym_old_by_name[s['name']] = s['idx']
    for s in secs:
        if s['type'] == SHT_RELA and s['name'] in KEEP_RELA:
            for (ro, si, rt, ra) in relas[s['info']]:
                referenced.add(si)

    old2new_sym = {}
    kept_syms = []
    for i, s in enumerate(syms):
        if i in referenced:
            old2new_sym[i] = len(kept_syms)
            kept_syms.append(s)

    # ---------- strtab / symtab 重建 ----------
    st = bytearray(b'\x00')
    sym_rows = []
    for s in kept_syms:
        if s['idx'] == 0:
            sym_rows.append((0, 0, 0, 0, 0, 0))
            continue
        no = len(st)
        st += s['name'].encode() + b'\x00'
        shndx_new = old2new.get(s['shndx'], s['shndx']) if (s['shndx'] != SHN_UNDEF
                                                            and s['shndx'] < 0xff00) else s['shndx']
        sym_rows.append((no, s['info'], s['other'], shndx_new, s['value'], s['size']))
    strtab_idx = push('.strtab', SHT_STRTAB, 0, 1, bytes(st))

    sym_data = bytearray()
    for no, info, other, shndx, value, size in sym_rows:
        sym_data += struct.pack('<IBBHQQ', no, info, other, shndx, value, size)
    symtab_idx = push('.symtab', SHT_SYMTAB, 0, 8, bytes(sym_data), link=strtab_idx, entsz=24)

    # ---------- rela 节（sym_idx 重映射到新符号表） ----------
    for s in secs:
        if s['type'] == SHT_RELA and s['name'] in KEEP_RELA:
            body = bytearray()
            for (ro, si, rt, ra) in relas[s['info']]:
                body += struct.pack('<QQq', ro, (old2new_sym[si] << 32) | rt, ra)
            push(s['name'], SHT_RELA, 0, 8, bytes(body),
                 link=symtab_idx, info=old2new[s['info']], entsz=24)

    # ---------- this_module 重定位（init/exit 指针, 用新符号索引） ----------
    tmrela = bytearray()
    for off, sname in ((MOD_INIT_OFF, 'init_module'), (MOD_EXIT_OFF, 'cleanup_module')):
        si = old2new_sym[sym_old_by_name[sname]]
        tmrela += struct.pack('<QQq', off, (si << 32) | R_AARCH64_ABS64, 0)
    push('.rela.gnu.linkonce.this_module', SHT_RELA, 0, 8, bytes(tmrela),
         link=symtab_idx, info=this_idx, entsz=24)

    # ---------- shstrtab（单遍构造） ----------
    names = [s['name'] for s in secs_out] + ['.shstrtab']
    shstr = bytearray(b'\x00')
    name_map = {}
    for nme in names:
        name_map[nme] = len(shstr)
        shstr += nme.encode() + b'\x00'
    shstr_idx = push('.shstrtab', SHT_STRTAB, 0, 1, bytes(shstr))

    # ---------- 布局 ----------
    n = len(secs_out)
    offsets = []
    cur = 64
    for s in secs_out:
        if s['type'] == SHT_NOBITS:
            offsets.append(cur)
            continue
        cur = (cur + s['align'] - 1) // s['align'] * s['align']
        offsets.append(cur)
        cur += len(s['data'])
    shoff = (cur + 7) // 8 * 8
    total = shoff + n * 64

    out = bytearray(total)
    for i, s in enumerate(secs_out):                 # 节数据写入
        if s['type'] == SHT_NOBITS:
            continue
        out[offsets[i]:offsets[i] + len(s['data'])] = s['data']
    out[0:64] = struct.pack('<16sHHIQQQIHHHHHH',
                            b'\x7fELF\x02\x01\x01\x00' + b'\x00' * 8,
                            1, 183, 1, 0, 64, shoff, 0,
                            64, 0, 0, 64, n, shstr_idx)
    for i, s in enumerate(secs_out):                 # 节头表写入
        out[shoff + i * 64: shoff + (i + 1) * 64] = struct.pack(
            '<IIQQQQIIQQ', name_map[s['name']], s['type'], s['flags'], 0, offsets[i],
            s['size'], s['link'], s['info'], s['align'], s['entsz'])

    open(out_path, 'wb').write(bytes(out))
    print('生成 %s (%dB) 模块=%s vermagic=%r' % (out_path, total, modname, VERMAGIC))
    return out


def verify(ko_path, modname):
    """模拟内核 load_module 的检查路径。"""
    d = open(ko_path, 'rb').read()
    ok = True
    e_shoff = struct.unpack('<Q', d[40:48])[0]
    entsz, num, strx = struct.unpack('<HHH', d[58:64])
    secs = []
    for i in range(num):
        o = e_shoff + i * entsz
        name, typ, flags, addr, offset, size, link, info, align, esz = struct.unpack(
            '<IIQQQQIIQQ', d[o:o + 64])
        secs.append({'name_off': name, 'name': '', 'type': typ, 'off': offset,
                     'size': size, 'link': link})
    so = secs[strx]['off']
    for s in secs:
        e = d.index(b'\x00', so + s['name_off'], so + entsz * num)
        s['name'] = d[so + s['name_off']:e].decode()
    print('[verify] sections=%d' % num)
    for s in secs:
        print('   %-36s type=%d size=%d' % (s['name'] or '(NULL)', s['type'], s['size']))

    def sec(n):
        for s in secs:
            if s['name'] == n:
                return s
        return None

    mi = sec('.modinfo')
    info = d[mi['off']:mi['off'] + mi['size']].replace(b'\x00', b'\n  ').decode()
    if ('vermagic=' + VERMAGIC) not in info:
        print('  ✗ vermagic 不匹配'); ok = False
    if 'license=GPL' not in info:
        print('  ✗ 缺 license'); ok = False
    print('  .modinfo:\n  ' + info)

    tm = sec('.gnu.linkonce.this_module')
    if tm['size'] != MOD_STRUCT_SIZE:
        print('  ✗ this_module 大小 %d != %d' % (tm['size'], MOD_STRUCT_SIZE)); ok = False
    name = d[tm['off'] + MOD_NAME_OFF: tm['off'] + MOD_NAME_OFF + 64].split(b'\x00')[0].decode()
    if name != modname:
        print('  ✗ name=%r != %r' % (name, modname)); ok = False

    symtab = sec('.symtab')
    strtab = sec('.strtab')
    und = []
    syms = []
    for i in range(symtab['size'] // 24):
        o = symtab['off'] + i * 24
        nm, inf, oth, shndx, val, sz = struct.unpack('<IBBHQQ', d[o:o + 24])
        e = d.index(b'\x00', strtab['off'] + nm, strtab['off'] + strtab['size'])
        sn = d[strtab['off'] + nm:e].decode()
        syms.append(sn)
        if shndx == SHN_UNDEF and i != 0:
            und.append(sn)
    print('  符号 %d 个: %r' % (len(syms), syms))
    print('  UND(内核解析): %r' % und)
    if 'printk' not in und:
        print('  ✗ printk 缺失'); ok = False
    # kallsyms 交叉验证: 所有 UND 符号必须存在于运行内核符号表
    import os
    ks_path = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           '..', 'research', 'kallsyms_names.txt')
    if os.path.isfile(ks_path):
        ks = open(ks_path, encoding='utf-8', errors='replace').read()
        for s in und:
            if not __import__('re').search(r' ' + __import__('re').escape(s) + r'$', ks, __import__('re').M):
                print('  ✗ UND 符号不在 kallsyms: %r' % s); ok = False
        print('  kallsyms 交叉验证: ✓')
    else:
        print('  (kallsyms 文件缺失, 跳过交叉验证)')

    rela = sec('.rela.gnu.linkonce.this_module')
    nrela = rela['size'] // 24
    init_ok = exit_ok = False
    for j in range(nrela):
        o = rela['off'] + j * 24
        ro, ri, ra = struct.unpack('<QQq', d[o:o + 24])
        si = ri >> 32
        print('  rela.this_module[%d]: member=%#x → %r' % (j, ro, syms[si]))
        if j == 0 and ro == MOD_INIT_OFF and syms[si] == 'init_module':
            init_ok = True
        if j == 1 and ro == MOD_EXIT_OFF and syms[si] == 'cleanup_module':
            exit_ok = True
    if not init_ok or not exit_ok:
        print('  ✗ init/exit 重定位异常'); ok = False

    print('[verify] %s' % ('通过 ✓' if ok else '失败 ✗'))
    return ok


if __name__ == '__main__':
    if len(sys.argv) < 4:
        sys.exit('用法: build_lkm.py <mod.o> <模块名> <输出.ko>')
    blob = build_ko(sys.argv[1], sys.argv[2], sys.argv[3])
    sys.exit(0 if verify(sys.argv[3], sys.argv[2]) else 1)
