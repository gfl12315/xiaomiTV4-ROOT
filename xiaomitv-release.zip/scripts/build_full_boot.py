# -*- coding: utf-8 -*-
"""
build_full_boot.py —— 构建完全体 boot.img（xmen 小米电视专用，瘦身版）

结构 = 官方 boot.img + 内核四补丁(P1~P4) + 迷你系统八件套（纯文本，无二进制）
设计要点：
  - 迷你系统(ramdisk)有硬体积上限：gz 约 2.4MB 内安全，超出即引导死循环（实测）
  - 因此所有二进制(su/dropbear/sftp/busybox/httpd)放 /data 持久分区，
    由 /heal 脚本在开机时引用，迷你系统只携带脚本与密钥（约 8KB）
三重自检：① 内核补丁回读 ② 迷你系统逐条目核对 ③ 体积安全区校验
"""
import struct, gzip, hashlib, os

PC   = os.path.dirname(os.path.abspath(__file__))            # Desktop/xiaomitv/scripts
CH   = os.environ.get('XM_CH', os.path.expanduser('~/xiaomitv-fw'))  # 固件工作目录
DESK = os.path.abspath(os.path.join(PC, '..'))

SRC_CPIO   = CH + '/fw/boot_exp/ramdisk3396.cpio'            # 官方 boot 的迷你系统
KERN_PATCH = CH + '/fw/boot_exp/kernel_patched.gz'           # 四补丁内核（A 版实测可引导）
HOSTKEY    = CH + '/dropbear-bin/hostkey_native'             # dropbear 原生格式主机钥匙
NEW2       = PC + '/install-recovery.sh.new2'                # ADB 常驻巡查版（接管 install-recovery）
STOCK_BOOT = DESK + '/backup/boot.img'                       # 官方 boot 分区 20MB 全镜像
OUT_IMG    = DESK + '/boot_full.img'

def parse_cpio(d):
    off, entries = 0, []
    while off < len(d):
        if d[off:off+6] != b'070701':
            t = d.find(b'070701', off)
            if t == -1: break
            off = t; continue
        f = [int(d[off+6+i*8:off+14+i*8], 16) for i in range(13)]
        namesize, filesize, mode = f[11], f[6], f[1]
        name = d[off+110:off+110+namesize-1].decode('latin1')
        data_off = (off + 110 + namesize + 3) & ~3
        if name == 'TRAILER!!!': break
        entries.append([name, mode, d[data_off:data_off+filesize]])
        off = data_off + filesize
        off = (off + 3) & ~3
    return entries

def pad4(b): return b + b'\x00' * ((4 - len(b) % 4) % 4)

def build_cpio(entries):
    out = b''
    for name, mode, data in entries:
        nb = name.encode('latin1') + b'\x00'
        hdr = b'070701' + ''.join('%08X' % v for v in
              [0, mode, 0, 0, 1, 0, len(data), 0, 0, 0, 0, len(nb), 0]).encode()
        out = pad4(out + hdr + nb)
        out = pad4(out + data)
    hdr = b'070701' + ''.join('%08X' % v for v in [0,0,0,0,1,0,0,0,0,0,0,11,0]).encode()
    out = pad4(out + hdr + b'TRAILER!!!\x00')
    out += b'\x00' * ((len(out) + 511) // 512 * 512 - len(out))
    return out

print('===== 1. 生成 /heal 脚本 =====')

HEAL_SH = '''#!/system/bin/sh
# xmen self-heal (init service, root with full caps)
H=/heal
L=/data/local/tmp/heal.log
{
echo "=== heal $(date) ==="
id

# A. su self-heal (binary from /data, reinstalled into /system if missing)
if [ ! -x /system/xbin/su ]; then
    if [ -f /data/local/tmp/su ]; then
        mount -o rw,remount /system
        cp /data/local/tmp/su /system/xbin/su
        chown 0:0 /system/xbin/su
        chmod 6755 /system/xbin/su
        echo "su reinstalled"
    fi
fi

# B. build.prop self-check
mount -o rw,remount /system
grep -q "^ro.adb.secure=0" /system/build.prop || echo "ro.adb.secure=0" >> /system/build.prop
grep -q "^ro.debuggable=1" /system/build.prop || echo "ro.debuggable=1" >> /system/build.prop

# B2. /etc/shells for dropbear shell validation (after /system rw)
mkdir -p /etc
echo /system/bin/sh > /etc/shells

# C. install-recovery hook self-check
if ! grep -q "adbwatch" /system/bin/install-recovery.sh 2>/dev/null; then
    if [ -f /data/local/tmp/install-recovery.sh.new2 ]; then
        cp /data/local/tmp/install-recovery.sh.new2 /system/bin/install-recovery.sh
        chown 0:0 /system/bin/install-recovery.sh
        chmod 750 /system/bin/install-recovery.sh
    fi
fi

# D. ssh env: root home dir (strict perms for dropbear) + passwd + profile
mkdir -p /data/local/tmp/sshhome/.ssh
cp $H/authorized_keys /data/local/tmp/sshhome/.ssh/authorized_keys
chown 0:0 /data/local/tmp/sshhome /data/local/tmp/sshhome/.ssh /data/local/tmp/sshhome/.ssh/authorized_keys
chmod 700 /data/local/tmp/sshhome /data/local/tmp/sshhome/.ssh
chmod 600 /data/local/tmp/sshhome/.ssh/authorized_keys
echo 'root:*:0:0:root:/data/local/tmp/sshhome:/system/bin/sh' > /system/etc/passwd
chown 0:0 /system/etc/passwd
chmod 600 /system/etc/passwd
cp $H/profile /data/local/tmp/sshhome/.profile 2>/dev/null

# E. sftp at dropbear's compiled-in path
mkdir -p /data/adb/sshserver
cp /data/local/tmp/sftp /data/adb/sshserver/sftp
chmod 755 /data/adb/sshserver/sftp

# F. convenience scripts
printf '#!/system/bin/sh\\nmount -o rw,remount /system && echo system-rw\\n' > /data/local/tmp/sysrw
printf '#!/system/bin/sh\\nmount -o ro,remount /system && echo system-ro\\n' > /data/local/tmp/sysro
chmod 755 /data/local/tmp/sysrw /data/local/tmp/sysro

# G. OTA off + ADB props + adbd restart
setprop persist.sys.ota.update 0
setprop ctl.stop bdupdate
setprop service.adb.tcp.port 5555
setprop persist.adb.tcp.port 5555
# adbd 协议状态偶发卡死（5555 已监听但握手失败），开机末期无条件重启一次
setprop ctl.restart adbd

sync
echo "=== heal done ==="
} > $L 2>&1
'''

ADBWATCH_SH = '''#!/system/bin/sh
# ADB 常驻巡查：每 20 秒检查，被关 20 秒内自动拉回
i=0
while true; do
    sleep 20
    i=$((i+1))
    ACT=""
    # 开机初期（前两轮）无条件重启 adbd：消灭偶发的握手卡死状态
    if [ $i -le 2 ]; then
        setprop ctl.restart adbd
        ACT="early_restart"
    fi
    EN=$(settings get global adb_enabled 2>/dev/null)
    if [ "$EN" != "1" ]; then
        settings put global adb_enabled 1
        ACT="$ACT adb_enabled"
    fi
    P=$(getprop service.adb.tcp.port 2>/dev/null)
    if [ "$P" != "5555" ]; then
        setprop persist.adb.tcp.port 5555
        setprop service.adb.tcp.port 5555
        ACT="$ACT tcpport"
    fi
    DIS=$(getprop sys.set_adb_disabled 2>/dev/null)
    if [ "$DIS" != "false" ]; then
        setprop sys.set_adb_disabled false
        ACT="$ACT disabled_flag"
    fi
    L=$(netstat -tln 2>/dev/null | grep -c ":5555")
    if [ "$L" = "0" ]; then
        setprop ctl.restart adbd
        ACT="$ACT adbd_restart"
    fi
    i=$((i+1))
    if [ -n "$ACT" ]; then
        echo "$(date) tick$i fixed:$ACT" >> /data/local/tmp/adbwatch.log
    fi
done
'''

PASSWD  = 'root:*:0:0:root:/data/local/tmp/sshhome:/system/bin/sh\n'
PROFILE = ('export PATH=/system/bin:/system/xbin:/data/local/tmp:$PATH\n'
           'export HOME=/data/local/tmp/sshhome\n'
           'export TERM=xterm-256color\n'
           "alias ll='ls -la'\n"
           'cd /data/local/tmp\n')

hostkey = open(HOSTKEY, 'rb').read()
pubkey  = open(DESK + '/ssh/tv_client_ed25519.pub', 'rb').read().strip()
new2    = open(NEW2, 'rb').read().replace(b'\r\n', b'\n')

heal_files = {
    'heal/heal.sh':                  (0o100755, HEAL_SH.encode('utf-8')),
    'heal/adbwatch.sh':              (0o100755, ADBWATCH_SH.encode('utf-8')),
    'heal/install-recovery.sh.heal': (0o100644, new2),
    'heal/hostkey':                  (0o100600, hostkey),
    'heal/authorized_keys':          (0o100644, pubkey + b'\n'),
    'heal/passwd':                   (0o100644, PASSWD.encode('utf-8')),
    'heal/profile':                  (0o100644, PROFILE.encode('utf-8')),
}
for n in heal_files: print('  ✓', n)

print('===== 2. 组装 ramdisk =====')
rd = open(SRC_CPIO, 'rb').read()
orig = parse_cpio(rd)
new_entries = []
for name, mode, data in orig:
    if name == 'default.prop':
        data = (data.decode('latin1').rstrip('\n') +
                '\nro.adb.secure=0\nro.debuggable=1\nservice.adb.tcp.port=5555\n').encode('latin1')
        print('  default.prop -> %d 字节 (+3 属性)' % len(data))
    elif name == 'init.rc':
        irc = data.decode('latin1').rstrip('\n') + '''
# === xmen full-control services ===
service heal /system/bin/sh /heal/heal.sh
    class main
    user root
    group root
    oneshot

service adbwatch /system/bin/sh /heal/adbwatch.sh
    class main
    user root
    group root

service dropbear /data/local/tmp/dropbear -r /heal/hostkey -p 22
    class main
    user root
    group root

service httpd /data/local/tmp/httpd 8080 /sdcard
    class main
    user root
    group root
'''
        data = irc.encode('latin1')
        print('  init.rc -> %d 字节 (+4 服务)' % len(data))
    new_entries.append((name, mode, data))
new_entries.append(('heal/', 0o40755, b''))
for name, (mode, data) in heal_files.items():
    new_entries.append((name, mode, data))

new_cpio = build_cpio(new_entries)
new_rd_gz = gzip.compress(new_cpio, 6)
print('cpio: %d 字节 (原 %d, +%d) | gzip: %d 字节' %
      (len(new_cpio), len(rd), len(new_cpio)-len(rd), len(new_rd_gz)))
assert len(new_rd_gz) < 2500000, 'ramdisk gz 超过 2.4MB 安全线!'

print('===== 3. 组装 boot_full.img =====')
d = open(STOCK_BOOT, 'rb').read()
kern = open(KERN_PATCH, 'rb').read()   # 已压缩的补丁内核（A 版实测可引导）
ps = struct.unpack('<I', d[36:40])[0]
kso = struct.unpack('<I', d[8:12])[0]
rs_old = struct.unpack('<I', d[16:20])[0]
ss = struct.unpack('<I', d[32:36])[0]
kp_old = (kso+ps-1)//ps
sec_off = 2048 + kp_old*ps + (rs_old+ps-1)//ps*ps
sec = d[sec_off:sec_off+ss]

kp = (len(kern)+ps-1)//ps
header = bytearray(d[:2048])
struct.pack_into('<I', header, 8, len(kern))
struct.pack_into('<I', header, 16, len(new_rd_gz))
h = hashlib.sha1(); h.update(kern); h.update(new_rd_gz); h.update(sec)
header[40:48] = h.digest()[:8]
img = bytes(header) + kern + b'\x00'*(kp*ps-len(kern)) \
    + new_rd_gz + b'\x00'*((ps-len(new_rd_gz)%ps)%ps) + sec
open(OUT_IMG, 'wb').write(img)
print('boot_full.img: %d 字节 (分区 20MB)' % len(img))
assert len(img) <= 20*1024*1024

print('===== 4. 三重自检 =====')
v = open(OUT_IMG, 'rb').read()
assert v[:8] == b'ANDROID!'
ks2 = struct.unpack('<I', v[8:12])[0]; rs2 = struct.unpack('<I', v[16:20])[0]
kp2 = (ks2+ps-1)//ps
k2 = gzip.decompress(v[2048:2048+ks2])
r2 = gzip.decompress(v[2048+kp2*ps : 2048+kp2*ps+rs2])
assert k2[0xe4525d:0xe4525d+11] == b'enforcinG=\x00', 'P1 失败'
assert k2[0x30909c:0x30909c+8] == bytes.fromhex('e00302aac0035fd6'), 'P2 失败'
assert k2.count(b'XMENOK01') == 2, 'P3/P4 失败'
assert k2[0x38:0x3c] == b'ARMd', 'Image magic 失败'
print('① 内核四补丁回读: P1✓ P2✓ XMENOK01 x2 ✓ ARMd✓')

e2 = dict((e[0], e[2]) for e in parse_cpio(r2))
assert b'ro.adb.secure=0' in e2['default.prop'] and b'ro.debuggable=1' in e2['default.prop']
assert b'service dropbear /data/local/tmp/dropbear -r /heal/hostkey -p 22' in e2['init.rc']
assert b'service httpd /data/local/tmp/httpd 8080 /sdcard' in e2['init.rc']
for n, (mode, data) in heal_files.items():
    assert n in e2 and e2[n] == data, '内容不符: ' + n
assert b'sshhome' in e2['heal/heal.sh'] and b'/etc/shells' in e2['heal/heal.sh']
for name, mode, data in orig:
    if name in ('default.prop', 'init.rc'): continue
    assert name in e2 and e2[name] == data, '原文件被改: ' + name
assert all(('heal/'+b) not in e2 for b in ('su', 'busybox', 'dropbear', 'sftp'))
print('② 迷你系统: 属性✓ 4服务✓ /heal 7项逐字节一致✓ 原文件未动✓ 无二进制✓')
print('③ 体积安全区: ramdisk gz %d 字节 < 2.4MB 上限 ✓' % rs2)
print('===== 构建完成: %s =====' % OUT_IMG)
