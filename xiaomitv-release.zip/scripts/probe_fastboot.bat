@echo off
REM probe_fastboot.bat — 小米电视4 fastboot 能力探测（只读，不刷写任何分区）
REM
REM 前提: 电视已通过 USB 公对公线(A-to-A)连接电脑 USB 口
REM       电视已 reboot fastboot 进入 fastboot 模式（等 MI logo 状态）
REM
REM 本脚本只执行三类只读命令: devices / getvar / reboot 退出。
REM 绝不执行: flash / erase / flashing unlock / boot —— 那些是刷写与状态变更命令。
REM
REM 任何一步 fastboot devices 为空: 电视断电重启即可回到系统，零损失。

if "%FASTBOOT%"=="" set "FASTBOOT=fastboot"
echo ===== fastboot 只读探测 =====
echo.
echo [1/3] 设备识别...
%FASTBOOT% devices -l
echo.
echo [2/3] 全量变量 getvar all（分区表/产品名/版本/锁定状态）...
%FASTBOOT% getvar all 2^>^&1 | findstr /v /c:"(bootloader) finished"
echo.
echo [3/3] 探测完成。以上输出请保存留证。
echo 退出方式二选一:
echo   A. fastboot reboot        （回到系统）
echo   B. 电视直接断电再通电     （boot 分区未动过，安全）
echo.
set /p DO_REBOOT=现在自动执行 fastboot reboot 回系统? [y/N]:
if /i "%DO_REBOOT%"=="y" %FASTBOOT% reboot
