#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
U-Boot / recovery 串口控制台
--------------------------------
用途：通过 CP2102(或同类 USB-TTL) 接电视 HDMI1 的 DDC 引脚，在 U-Boot 阶段
      读写控制台、发送命令、把全部输出落盘留证。

用法：
  python uboot_console.py --list
  python uboot_console.py --port COM5 --monitor 40
  python uboot_console.py --port COM5 --auto-boot-twrp
  python uboot_console.py --port COM5 --send "factorydata read console_enable"

参数说明：
  --port      串口号，Windows 形如 COM5，Linux 形如 /dev/ttyUSB0
  --baud      波特率，Amlogic 小米电视默认 921600
  --log       日志文件，默认 ./uboot_<时间>.log（XM_LOGDIR 可覆盖）
  --monitor   纯监听 N 秒，打印并把原始字节写日志
  --auto-boot-twrp
              监听期间一旦出现 U-Boot 提示符或 "Hit any key" 提示，
              自动发送从 U 盘引导 TWRP 的命令序列
  --send      发送一条命令后立即退出（自动补 \\r）

注意：U-Boot 只认 CR（\\r），不认 LF。脚本里统一用 \\r。
"""

import argparse
import datetime
import os
import sys
import time

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    sys.stderr.write("缺少 pyserial：python -m pip install pyserial\n")
    sys.exit(2)

DEFAULT_BAUD = 921600
DEFAULT_LOG_DIR = os.environ.get('XM_LOGDIR', '.')


def list_serial_ports():
    ports = list(list_ports.comports())
    if not ports:
        print("未发现任何串口设备。")
        print("检查：① CP2102 是否插好 ② 驱动是否安装（设备管理器里应出现 Silicon Labs CP210x）")
        return
    print("可用串口：")
    for p in ports:
        print("  %-10s %s" % (p.device, p.description))
        if p.hwid:
            print("             %s" % p.hwid)


def now_stamp():
    return datetime.datetime.now().strftime("%Y%m%d_%H%M%S")


def open_port(port, baud):
    return serial.Serial(
        port=port,
        baudrate=baud,
        bytesize=serial.EIGHTBITS,
        parity=serial.PARITY_NONE,
        stopbits=serial.STOPBITS_ONE,
        timeout=0.2,
        write_timeout=2,
        rtscts=False,
        dsrdtr=False,
        xonxoff=False,
    )


class Console:
    def __init__(self, ser, logpath):
        self.ser = ser
        self.log = open(logpath, "ab", buffering=0)
        self.buf = bytearray()
        self.logpath = logpath

    def close(self):
        try:
            self.log.close()
        except Exception:
            pass

    def pump(self, seconds, on_chunk=None):
        """读取 seconds 秒，全部落盘并打印。返回累计读到的文本。"""
        end = time.time() + seconds
        text = []
        while time.time() < end:
            try:
                data = self.ser.read(4096)
            except serial.SerialException as e:
                print("\n[串口异常] %s" % e)
                break
            if not data:
                continue
            self.log.write(data)
            self.buf.extend(data)
            s = data.decode("utf-8", "replace")
            text.append(s)
            sys.stdout.write(s)
            sys.stdout.flush()
            if on_chunk:
                on_chunk(s)
        return "".join(text)

    def send(self, cmd, wait=0.15, cr=True):
        payload = cmd.encode("utf-8") + (b"\r" if cr else b"")
        self.ser.write(payload)
        self.ser.flush()
        mark = "\n>>> %s\n" % cmd
        sys.stdout.write(mark)
        self.log.write(mark.encode("utf-8"))
        time.sleep(wait)


TWRP_SEQ = [
    # 先敲回车确认控制台活着
    ("", 0.4),
    # 关掉可能存在的自动启动倒计时干扰
    ("", 0.3),
    # 初始化 USB 子系统（Amlogic u-boot 里通常叫 usb start）
    ("usb start", 2.0),
    # 列出 U 盘里根目录，确认能读到 recovery.img
    ("fatls usb 0 /", 1.5),
    # 把镜像读到内存。0x1080000 与官方 boot.img 的 kernel_addr 一致，u-boot 认这个地址
    ("fatload usb 0 0x1080000 recovery.img", 3.0),
    # 从该地址启动
    ("bootm 0x1080000", 1.0),
]

PROMPT_HINTS = [
    "Hit any key",
    "hit any key",
    "xmen#",
    "xmen $",
    "gxbaby#",
    "gxl#",
    "mulan#",
    "=>",
    "aml#",
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true", help="列出串口")
    ap.add_argument("--port", help="串口设备名，如 COM5")
    ap.add_argument("--baud", type=int, default=DEFAULT_BAUD)
    ap.add_argument("--log", help="日志路径")
    ap.add_argument("--monitor", type=float, help="监听秒数")
    ap.add_argument("--auto-boot-twrp", action="store_true", help="检测到 U-Boot 提示符后自动引导 U 盘 TWRP")
    ap.add_argument("--send", help="发送一条命令后退出")
    args = ap.parse_args()

    if args.list:
        list_serial_ports()
        return

    if not args.port:
        ap.print_help()
        return

    logpath = args.log or os.path.join(DEFAULT_LOG_DIR, "uboot_%s.log" % now_stamp())
    try:
        ser = open_port(args.port, args.baud)
    except serial.SerialException as e:
        sys.stderr.write("打开串口失败：%s\n" % e)
        sys.stderr.write("排查：① 串口是否被 PuTTY/其他工具占用 ② 端口号是否正确 ③ 驱动是否装好\n")
        sys.exit(3)

    con = Console(ser, logpath)
    print("已打开 %s @ %d 8N1，日志：%s" % (args.port, args.baud, logpath))
    print("-" * 60)

    try:
        if args.send:
            con.send(args.send)
            con.pump(1.5)
            return

        if args.auto_boot_twrp:
            print("等待 U-Boot 提示符（最多 90 秒）。请在电视上电/重启阶段观察。")
            deadline = time.time() + 90
            fired = False

            def watch(chunk):
                nonlocal fired
                if fired:
                    return
                for hint in PROMPT_HINTS:
                    if hint in chunk:
                        print("\n[命中提示符 %r] 开始发送引导命令" % hint)
                        fired = True
                        break

            while time.time() < deadline and not fired:
                con.pump(1.0, watch)
            if not fired:
                print("\n[超时] 90 秒内没看到 U-Boot 提示符。")
                print("可能：① 串口线接反或没接对引脚 ② 波特率不是 921600 ③ 该机型 U-Boot 控制台被关闭")
                print("日志已保存：%s" % logpath)
                return

            for cmd, wait in TWRP_SEQ:
                con.send(cmd, wait=wait)
                con.pump(wait)
            print("\n[已完成引导命令序列] 观察屏幕是否进入 TWRP。")
            con.pump(10)
            return

        secs = args.monitor if args.monitor else 30
        print("监听 %.0f 秒（Ctrl+C 提前结束）..." % secs)
        con.pump(secs)
    except KeyboardInterrupt:
        print("\n[中断]")
    finally:
        con.close()
        try:
            ser.close()
        except Exception:
            pass
        print("-" * 60)
        print("日志：%s" % logpath)


if __name__ == "__main__":
    main()
