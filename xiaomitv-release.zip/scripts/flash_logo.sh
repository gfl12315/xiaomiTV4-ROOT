#!/system/bin/sh
# flash_logo.sh — 小米电视4 开机 Logo 替换（电视端执行）
#
# 设计要求：未拿到 Root 权限时不做任何替换；确认 Root 后才写入，
# 并把本次替换作为"设备已获得最高权限"的明显提示。
# 写入前自动备份当前 logo 分区，写坏可随时回滚。
#
# 用法（adb shell 或 本机终端）:
#   sh /data/local/tmp/flash_logo.sh /data/local/tmp/logo_areyouok.img
#
# 退出码: 0 成功 / 1 未 Root 或参数缺失 / 2 备份或写入失败

LOGO_DEV="/dev/block/logo"
IMG="$1"
STAMP=$(date +%Y%m%d_%H%M%S)
BACKUP="/data/local/tmp/logo_backup_${STAMP}.img"

echo "=== 小米电视4 开机 Logo 替换 ==="

# ---- Root 门卫: 不是 root 什么都不碰 ----
if [ "$(id -u)" != "0" ]; then
    if command -v su >/dev/null 2>&1 && su -c 'id -u' 2>/dev/null | grep -q '^0$'; then
        echo "[i] 通过 su 获得 root"
        exec su -c "sh $0 $IMG"   # 以 root 重跑自身
    fi
    echo "[!] 未检测到 Root 权限，按设计跳过 Logo 替换。"
    echo "    先完成提权步骤（见 README 步骤3），再来执行本脚本。"
    exit 1
fi
echo "[✓] Root 权限确认，允许替换"

# ---- 参数与目标检查 ----
if [ -z "$IMG" ] || [ ! -f "$IMG" ]; then
    echo "[!] 用法: sh $0 <logo镜像路径>"
    echo "    例: sh $0 /data/local/tmp/logo_areyouok.img"
    exit 1
fi
if [ ! -e "$LOGO_DEV" ]; then
    echo "[!] 找不到 logo 分区 $LOGO_DEV，本机型不适用"
    exit 2
fi

# ---- 镜像头快速自检（AML_RES! V2 + 条目 magic）----
magic=$(dd if="$IMG" bs=1 skip=8 count=8 2>/dev/null)
if [ "$magic" != "AML_RES!" ]; then
    echo "[!] $IMG 头部不是 AML_RES!，拒绝写入"
    exit 2
fi
ver=$(dd if="$IMG" bs=1 skip=4 count=4 2>/dev/null | od -A n -t u1 | awk '{print $1}')
echo "[i] 镜像格式: AML_RES! V$ver"

# ---- 备份当前 logo（回滚保险）----
echo "[i] 备份当前 logo → $BACKUP"
dd if="$LOGO_DEV" of="$BACKUP" bs=4096 count=1024 2>/dev/null || exit 2
bmagic=$(dd if="$BACKUP" bs=1 skip=8 count=8 2>/dev/null)
if [ "$bmagic" != "AML_RES!" ]; then
    echo "[!] 备份内容异常（原分区非 AML_RES! 格式），中止"
    exit 2
fi
echo "[✓] 备份完成 ($(ls -l "$BACKUP" | awk '{print $5}') 字节)"

# ---- 写入 ----
# 本机 dd 不支持 conv= 参数（见 README 注意事项），dd 默认即为覆盖写不动后续扇区
sz=$(ls -l "$IMG" | awk '{print $5}')
echo "[i] 写入 $IMG ($sz 字节) → $LOGO_DEV"
dd if="$IMG" of="$LOGO_DEV" bs=4096 2>/dev/null
sync

# ---- 回读校验（截取分区前 sz 字节与镜像逐字节比对）----
n=$(( (sz + 4095) / 4096 ))
VERIFY=/data/local/tmp/.logo_verify
dd if="$LOGO_DEV" of="$VERIFY" bs=4096 count=$n 2>/dev/null
head -c "$sz" "$VERIFY" > "${VERIFY}.cut"
if ! cmp -s "$IMG" "${VERIFY}.cut"; then
    echo "[!] 写入后回读不一致！立即用备份回滚..."
    dd if="$BACKUP" of="$LOGO_DEV" bs=4096 2>/dev/null
    sync
    echo "[!] 已回滚到原 logo。请检查存储/USB 传输是否完整后重试。"
    exit 2
fi
rm -f "$VERIFY" "${VERIFY}.cut"
echo "[✓] 回读校验一致"
echo ""
echo "=== 替换成功 ==="
echo "本设备已获得最高权限（此 Logo 即 Root 后的标识）。"
echo "重启电视即可看到新开机画面。"
echo "回滚命令: dd if=$BACKUP of=$LOGO_DEV bs=4096; sync"
exit 0
