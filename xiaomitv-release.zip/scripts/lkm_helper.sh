#!/system/bin/sh
cat > /dev/null
Q=/data/local/tmp/lkm_queue.txt
if [ -f "$Q" ]; then
  while read ko; do
    /system/bin/insmod "$ko"
  done < "$Q"
  rm -f "$Q"
fi
R=/data/local/tmp/rmmod_queue.txt
if [ -f "$R" ]; then
  while read mo; do
    /system/bin/rmmod "$mo"
  done < "$R"
  rm -f "$R"
fi
exit 0
