#!/system/bin/sh
# backup_daily.sh — 核心分区每日滚动备份 (kcrontab 每日调用)
# 策略: 星期几(0-6)覆盖式轮换, 保留最近 7 份; 只备份关键引导分区(~41MB/日)
#   boot 20M / recovery 16M / env 256K / misc 512K / logo 4M
# 恢复: dd if=/data/adb/backup/dayN/boot.img of=/dev/block/boot bs=4096
D=/data/adb/backup
DOW=$(date +%w 2>/dev/null)
case "$DOW" in ''|*[!0-9]*) DOW=0 ;; esac
# 空间策略: /data 仅 317MB 可用 → 3 份轮换 (~123MB 上限)
BK=$D/day$((DOW % 3))
mkdir -p $BK

dd if=/dev/block/boot     of=$BK/boot.img     bs=4096 2>/dev/null
dd if=/dev/block/recovery of=$BK/recovery.img bs=4096 2>/dev/null
dd if=/dev/block/env      of=$BK/env.img      bs=262144 2>/dev/null
dd if=/dev/block/misc     of=$BK/misc.img     bs=4096 2>/dev/null
dd if=/dev/block/logo     of=$BK/logo.img     bs=4096 2>/dev/null

md5sum $BK/boot.img $BK/recovery.img $BK/env.img $BK/misc.img $BK/logo.img > $BK/md5.txt
sync
echo "$(date "+%Y-%m-%d %H:%M") day$DOW backup done $(du -sk $BK 2>/dev/null | awk '{print $1}')KB" >> $D/backup.log
