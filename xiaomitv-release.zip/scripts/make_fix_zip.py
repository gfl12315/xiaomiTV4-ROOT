# -*- coding: utf-8 -*-
"""
make_fix_zip.py [env_new.bin]

生成 TWRP 可刷入的救援包 fix.zip。刷入后做两件事：
  1. 恢复 /system/bin/systemcontrol（从 systemcontrol.disabled 改回原名）
  2. 把 env 分区重写为 permissive 版（env_new.bin 从 zip 解到 /tmp 后 dd 写入）

用途：误禁 systemcontrol 导致卡开机 logo 时，进 TWRP -> Install -> fix.zip，
全程零打字；也适用于 env 被改回 enforcing 后的重新固化。

用法:
  python make_fix_zip.py env_new.bin     # env_new.bin 由 patch_env.py 生成
"""
import zipfile, sys, os

env_path = sys.argv[1] if len(sys.argv) > 1 else 'env_new.bin'
env = open(env_path, 'rb').read()
assert env[:8] != b'ANDROID!', '传入的是 boot 镜像，不是 env 分区镜像'

UB = b'''#!/sbin/sh
# fix: restore systemcontrol + env permissive
OUT=/proc/self/fd/$2
ui() {
  echo "ui_print $1" > $OUT 2>/dev/null
  echo "ui_print" > $OUT 2>/dev/null
}
ui "=== fix: restore systemcontrol ==="
mkdir -p /system 2>/dev/null
mount /system 2>/dev/null
mount -o rw,remount /system 2>/dev/null
[ -d /system/bin ] || mount -t ext4 -o rw /dev/block/system /system 2>/dev/null
if [ -f /system/bin/systemcontrol.disabled ]; then
  mv /system/bin/systemcontrol.disabled /system/bin/systemcontrol
  chmod 755 /system/bin/systemcontrol
  sync
  ui "FIXED_OK systemcontrol restored"
elif [ -f /system/bin/systemcontrol ]; then
  ui "ALREADY_OK systemcontrol present"
else
  ui "WARN systemcontrol not found"
fi
if [ -f /tmp/env_new.bin ]; then
  ui "writing env (permissive)"
  dd if=/tmp/env_new.bin of=/dev/block/env bs=4096 count=17 2>/dev/null
  sync
  ui "env done"
fi
ui "=== Now Reboot > System ==="
exit 0
'''

z = zipfile.ZipFile('fix.zip', 'w', zipfile.ZIP_DEFLATED)
zi = zipfile.ZipInfo('META-INF/com/google/android/update-binary', (2026, 1, 1, 0, 0, 0))
zi.external_attr = 0o755 << 16        # 可执行权限位，TWRP 按此权限解压
zi.compress_type = zipfile.ZIP_DEFLATED
z.writestr(zi, UB)
z.writestr('env_new.bin', env)
z.close()
print('fix.zip: %d 字节 (env_new.bin %d 字节)' % (os.path.getsize('fix.zip'), len(env)))
