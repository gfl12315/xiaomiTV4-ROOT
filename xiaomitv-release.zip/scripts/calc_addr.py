# -*- coding: utf-8 -*-
"""
calc_addr.py <vmlinux.img> <设备kallsyms导出>
设备端导出:  adb shell "cat /proc/kallsyms" > kallsyms_dev.txt
原理:
  1. 在 Image 中定位 kallsyms_addresses 数组（连续递增 u64，允许相等，内核地址范围），
     允许重复地址，命中后向前回溯至数组真实起点；
  2. 数组末尾向后跳过零填充，找到第一个非零 u64 应等于符号总数（双重校验）；
  3. 与设备 /proc/kallsyms 的纯内核符号名（跳过 [module] 行）按序一一配对；
  4. 校验 sys_call_table[244..259] 均指向 sys_ni_syscall。
"""
import struct, sys

BASE = 0xffffffc000000000          # 线性映射: va = phys + BASE
data = open(sys.argv[1], 'rb').read()
N = len(data)

# ---- 1. 定位符号地址数组 ----
cand = -1
for off in range(0x100000, N - 65536, 8):
    v = struct.unpack_from('<Q', data, off)[0]
    if BASE <= v < BASE + 0x100000000:
        ok, prev = True, v
        for k in range(1, 4096):
            nv = struct.unpack_from('<Q', data, off + 8*k)[0]
            if not (prev <= nv < BASE + 0x100000000):
                ok = False; break
            prev = nv
        if ok:
            cand = off; break
if cand == -1:
    sys.exit('未找到 kallsyms_addresses')
while cand >= 8:                    # 回溯到数组真实起点
    v = struct.unpack_from('<Q', data, cand - 8)[0]
    if BASE <= v <= struct.unpack_from('<Q', data, cand)[0] and v < BASE + 0x100000000:
        cand -= 8
    else:
        break

addrs, prev, off = [], -1, cand
while off + 8 <= N:
    v = struct.unpack_from('<Q', data, off)[0]
    if v < prev or not (BASE <= v < BASE + 0x100000000):
        break
    addrs.append(v); prev = v; off += 8

# ---- 2. num_syms ----
num_off = None
for k in range(512):
    v = struct.unpack_from('<Q', data, off + 8*k)[0]
    if v != 0:
        num_off = off + 8*k; break
num_syms = struct.unpack_from('<Q', data, num_off)[0]
assert num_syms == len(addrs), 'num_syms(%d) != 数组计数(%d)' % (num_syms, len(addrs))
print('符号数: %d, _text = 0x%x' % (len(addrs), addrs[0]))

# ---- 3. 与设备符号名按序配对 ----
names = []
for line in open(sys.argv[2], encoding='latin1'):
    p = line.split()
    if len(p) < 3 or '[' in p[-1]:   # 跳过模块符号
        continue
    names.append(p[2])
assert len(names) == len(addrs), \
    '设备纯内核符号数(%d) != 镜像地址数(%d) —— 非同一内核!' % (len(names), len(addrs))

syms = dict(zip(names, addrs))

# ---- 4. 校验 sys_call_table 空槽 ----
sct   = syms['sys_call_table']
ni    = syms['sys_ni_syscall']
text  = addrs[0]                    # _text 虚拟地址
ents  = [struct.unpack_from('<Q', data, sct - text + 8*k)[0] for k in range(320)]
assert len(set(ents[244:260])) == 1 and ents[244] == ni, '空槽校验失败'
print('sys_call_table[244..259] 空槽校验通过')

# ---- 5. 输出 ----
out = {
    'KLN_ADDR':  syms['kallsyms_lookup_name'],
    'SLOT_PHYS': sct + 244*8 - BASE,
    'selinux_enforcing': syms['selinux_enforcing'],
    'core_pattern':      syms['core_pattern'],
    'memcpy':            syms['memcpy'],
}
with open('syms.txt', 'w') as f:
    for n, a in zip(names, addrs):
        f.write('%016x %s\n' % (a, n))
for k, v in out.items():
    print('%-20s = %x' % (k, v))
