# -*- coding: utf-8 -*-
"""
patch_env.py <env_backup.bin>
从设备导出:  adb shell "su -c 'dd if=/dev/block/env of=/sdcard/env_backup.bin bs=262144'"
             adb pull /sdcard/env_backup.bin env_backup.bin
流程:
  1. 以头部 CRC32 试算确定 ENV_SIZE;
  2. initargs 中 androidboot.selinux=enforcing -> permissive;
  3. 重算 CRC 写回头部, 输出 env_new.bin。
"""
import zlib, struct, sys

d = bytearray(open(sys.argv[1], 'rb').read())
crc_stored = struct.unpack('<I', d[:4])[0]
print('头部 CRC = 0x%08x' % crc_stored)

env_size = None
for size in [0x1000,0x2000,0x4000,0x8000,0x10000,0x20000,0x40000,0x80000]:
    if zlib.crc32(bytes(d[4:size])) & 0xffffffff == crc_stored:
        env_size = size; break
assert env_size, 'CRC 未匹配任何候选长度'
print('ENV_SIZE = 0x%x' % env_size)

old = b'androidboot.selinux=enforcing'
new = b'androidboot.selinux=permissive'
assert d.count(old) == 1, 'initargs 中 selinux 值定位异常'
i = d.find(old)
d[i:i+len(old)] = new

crc = zlib.crc32(bytes(d[4:env_size])) & 0xffffffff
d[0:4] = struct.pack('<I', crc)
open('env_new.bin', 'wb').write(bytes(d))
print('新 CRC = 0x%08x, 已输出 env_new.bin' % crc)
