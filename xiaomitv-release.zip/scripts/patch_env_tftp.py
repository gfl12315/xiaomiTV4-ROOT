#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""patch_env_tftp.py — env 分区重建式修改: 注入 TFTP 网络刷机参数与探针 (v4 三态探针版)

用法 (操作阶段):
  1. 先从电视导出最新 env (base64 中转防 tty 换行污染二进制):
     adb shell "su -c 'dd if=/dev/block/env bs=4096 count=16 | base64'" > env_b64.txt
     python -c "import base64;z=zipfile"  # 或用 scripts 内的解码片段: 前 1150 行 join 解码取前 65536B
     adb shell "su -c 'dd if=/dev/block/env of=/data/local/tmp/env_cur.bin'" && adb pull ...
  2. python patch_env_tftp.py env_cur.bin env_new.bin --server <PC局域网IP>
  3. 自检通过后写回:
     adb push env_new.bin /data/local/tmp/
     adb shell "su -c 'dd if=/data/local/tmp/env_new.bin of=/dev/block/env bs=4096 count=16; sync'"
  4. **写回后 MD5 双侧核对**:
     adb shell "su -c 'dd if=/dev/block/env bs=4096 count=16 | md5sum'"   (与本地 Get-FileHash 对比)
  5. 回滚: 写回前的 env 备份原样 dd 写回

改动内容:
  - switch_bootmode normal 分支尾段插探针 (v4): sleep 2 等 PHY 协商 + ping 三态
    * ping 通 + tftp 成功       -> tftp_ok=2 (全通, 可进入真刷写阶段)
    * ping 通 + tftp 失败       -> tftp_ok=1 (查 PC 端 UDP 69 入站防火墙/文件名)
    * ping 不通                 -> tftp_ok=9 (U-Boot 阶段网络层不通, 优先加大前置等待)
  - update 变量: init_display 后插探针段 (冷启动 irdetect 路径用, 原流程 100% 保留)
  - 追加: serverip / ipaddr / netmask / gatewayip / tftpfile / tftp_en 六个网络变量
安全设计:
  - tftp_en 门控: 置 0 时探针跳过, 开机零延迟零网络行为 (验证完归零)
  - 探针只下载到内存 (loadaddr), 不写任何分区
  - bootcmd / BCB 触发链一字不动
  - env CRC 覆盖 [4:0x10000) 共 0xFFFC 字节 (本设备无 flags 字节); CRC 错误时
    U-Boot 回落内置默认 env, 不会直接砖机
"""
import sys, struct, zlib, argparse

HDR = 4                        # 4B CRC32 (本设备无 flags 字节, 变量区从 offset 4 直接开始)
DATA_SIZE = 0xFFFC             # 数据区 0xFFFC = ENV_SIZE 0x10000 - 4B CRC (含 CRC 的总长才是 0x10000)

# ---- update 变量探针 (冷启动 irdetect 路径) ----
PROBE = ("if tftp ${loadaddr} ${tftpfile}; then setenv tftp_ok 1; else setenv tftp_ok 0; fi;"
         "saveenv;")
NEW_UPDATE = ("run init_display;"
              + PROBE +
              "setenv bootargs ${bootargs} aml_dt=${aml_dt};"
              "editbootargs androidboot.selinux permissive;"
              "if usb start 0; then run recovery_from_udisk;fi;run recovery_from_flash;")

# ---- switch_bootmode 的 reboot update 分支插桩锚点 (实测该路径走固件级 recovery 不经 env,
#      保留插桩是为覆盖固件差异; 若锚点不匹配请按实际 switch_bootmode 内容调整) ----
SB_ANCHOR = ("else if test ${reboot_mode} = update; then run init_display;")
NEW_SB_FIX = ("else if test ${reboot_mode} = update; then run init_display;" + PROBE)

# ---- normal 分支探针 v3 (双标记版: 仅在 env 无探针时首次注入用) ----
NORMAL_ANCHOR = "run init_display;if imgread kernel boot"
PROBE_NORMAL_V3 = ('run init_display;'
                   'if test ${tftp_en} = 1; then '
                   'if tftp ${loadaddr} ${tftpfile}; then setenv tftp_ok 1; else setenv tftp_ok 0; fi; '
                   'saveenv; fi;'
                   'if imgread kernel boot')

# ---- normal 分支探针 v4 (三态标记版: 从 v3 段升级时用) ----
NORMAL_V3_OLD = ('run init_display;'
                 'if test ${tftp_en} = 1; then '
                 'if tftp ${loadaddr} ${tftpfile}; then setenv tftp_ok 1; else setenv tftp_ok 0; fi; '
                 'saveenv; fi;'
                 'if imgread kernel boot')
PROBE_NORMAL_V4 = ('run init_display;'
                   'if test ${tftp_en} = 1; then '
                   'sleep 2;'
                   'if ping ${serverip}; then '
                   'if tftp ${loadaddr} ${tftpfile}; then setenv tftp_ok 2; else setenv tftp_ok 1; fi; '
                   'else setenv tftp_ok 9; fi; '
                   'saveenv; fi;'
                   'if imgread kernel boot')

ADD_VARS = {                    # --server 指定 PC 局域网 IP, 其余固定
    "netmask":  "255.255.252.0",   # /22, 按实际网络调整
    "gatewayip": "192.168.1.1",    # 按实际网关调整
    "ipaddr":   "192.168.1.200",   # U-Boot 阶段专用静态 IP, 避开 DHCP 常用段; 按实际网段调整
    "tftpfile": "test8m.bin",      # 探针下载的测试文件 (8MB), 真刷写阶段换 boot.img 等
    "tftp_en":  "1",               # 探针门控: 1=每次开机执行; 验证完置 0 归零日常零影响
}

def parse_env(body):
    """变量区 → dict (保留原始顺序)"""
    out = {}
    for item in body.split(b"\x00"):
        if not item or b"=" not in item:
            continue
        k, _, v = item.partition(b"=")
        out[k.decode("utf-8", "replace")] = v.decode("utf-8", "replace")
    return out

def serialize(d):
    """dict → 数据区 (单\\0分隔, 双\\0结尾, 补齐 DATA_SIZE=0xFFFC)"""
    blob = b"".join(
        k.encode() + b"=" + v.encode() + b"\x00" for k, v in d.items()
    ) + b"\x00"
    assert len(blob) <= DATA_SIZE - 4, f"变量区超限: {len(blob)}"
    return blob + b"\x00" * (DATA_SIZE - len(blob))

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("src", help="当前 env 分区导出 (env_cur.bin)")
    ap.add_argument("dst", help="输出文件 (env_new.bin)")
    ap.add_argument("--server", required=True, help="PC 局域网 IP (TFTP 服务器)")
    ap.add_argument("--probe", choices=["v3", "v4"], default="v4",
                    help="normal 分支探针版本: v3=双标记(仅 tftp), v4=三态(sleep+ping, 默认)")
    a = ap.parse_args()

    raw = open(a.src, "rb").read()
    assert len(raw) >= HDR + DATA_SIZE, "env 导出过小"
    crc_stored = struct.unpack("<I", raw[0:4])[0]

    # 1) 解析 (CRC 覆盖 [HDR:HDR+DATA_SIZE))
    body = raw[HDR:HDR + DATA_SIZE]
    if zlib.crc32(body) & 0xFFFFFFFF != crc_stored:
        sys.exit("CRC 校验失败——env 基线异常, 先重新导出")
    print(f"[i] CRC 匹配, 数据区 [{HDR:#x}:{HDR+DATA_SIZE:#x}) = {DATA_SIZE} B")
    d = parse_env(body)
    print(f"[i] 现有变量 {len(d)} 个")
    orig_keys = set(d.keys())                    # 自检基准
    bootcmd_orig = d.get("bootcmd", "")

    # 2) update 变量插探针 (幂等: 已含探针则跳过)
    if "if tftp" not in d.get("update", ""):
        d["update"] = NEW_UPDATE
        print("[i] update 变量已插入 tftp 探针段")
    else:
        print("[i] update 变量已含探针, 跳过")

    # 3) switch_bootmode normal 分支探针 (三档适配: 无探针→v3/v4; 已有 v3→v4; 已有 v4→跳过)
    sb = d.get("switch_bootmode", "")
    probe = PROBE_NORMAL_V4 if a.probe == "v4" else PROBE_NORMAL_V3
    if "if tftp" in sb and "if ping" not in sb and NORMAL_V3_OLD in sb:
        # v3 → v4 升级: 精确替换 v3 段 (链式 replace, 每次基于上一步结果)
        sb = sb.replace(NORMAL_V3_OLD, PROBE_NORMAL_V4, 1)
        print("[i] normal 分支探针 v3 → v4 升级完成")
    elif NORMAL_ANCHOR in sb:
        sb2 = sb.replace(SB_ANCHOR, NEW_SB_FIX, 1)          # update 分支 (若锚点存在)
        anchor = NORMAL_ANCHOR if a.probe == "v3" else NORMAL_V3_OLD.replace(
            'run init_display;if test ${tftp_en} = 1; then ',
            'run init_display;if test ${tftp_en} = 1; then ')  # v4 无独立锚点, 用 v3 段整体
        if NORMAL_ANCHOR in sb2:
            seg = PROBE_NORMAL_V3 if a.probe == "v3" else PROBE_NORMAL_V4
            sb2 = sb2.replace(NORMAL_ANCHOR, seg, 1)
        sb = sb2
        print(f"[i] normal 分支探针 {a.probe} 首次注入")
    elif "if ping" in sb:
        print("[i] normal 分支已是 v4 三态探针, 跳过")
    else:
        print("[i] normal 分支锚点未匹配, 仅注入变量 (switch_bootmode 未改动)")
    d["switch_bootmode"] = sb

    # 4) 网络变量
    d["serverip"] = a.server
    for k, v in ADD_VARS.items():
        d[k] = v
    print(f"[i] serverip={a.server} ipaddr={ADD_VARS['ipaddr']} tftpfile={ADD_VARS['tftpfile']} tftp_en={ADD_VARS['tftp_en']}")

    # 5) 重序列化 + CRC (4B CRC + 0xFFFC 数据 = 0x10000 整)
    body_new = serialize(d)
    crc_new = zlib.crc32(body_new) & 0xFFFFFFFF
    out = struct.pack("<I", crc_new) + body_new
    open(a.dst, "wb").write(out)
    print(f"[i] 输出 {a.dst} ({len(out)} B, CRC={crc_new:#010x})")

    # 6) 自检: 重读新文件逐项验证
    chk = open(a.dst, "rb").read()
    c2 = struct.unpack("<I", chk[0:4])[0]
    assert zlib.crc32(chk[HDR:HDR + DATA_SIZE]) & 0xFFFFFFFF == c2, "自检 CRC FAIL"
    assert len(chk) == 0x10000, f"输出长度应为 0x10000, 实际 {len(chk):#x}"
    d2 = parse_env(chk[HDR:HDR + DATA_SIZE])
    sb2 = d2["switch_bootmode"]
    assert d2["serverip"] == a.server, "自检 serverip FAIL"
    assert d2["bootcmd"] == bootcmd_orig, "自检 bootcmd 被动 FAIL"       # 红线: bootcmd 不动
    assert orig_keys - set(d2.keys()) == set(), "自检 丢键异常"
    NET_KEYS = {"serverip", "ipaddr", "netmask", "gatewayip", "tftpfile", "tftp_en"}
    assert NET_KEYS <= set(d2.keys()), f"自检 网络变量缺失: {NET_KEYS - set(d2.keys())}"
    if a.probe == "v4" and "if ping" in sb2:
        assert "sleep 2" in sb2 and "ping ${serverip}" in sb2, "自检 v4 探针要素 FAIL"
        assert all(f"tftp_ok {m}" in sb2 for m in ("2", "1", "9")), "自检 三态标记 FAIL"
        assert sb2.count("if tftp") >= 2, "自检 探针计数 FAIL"
        print("[i] 自检: CRC ✓ / v4 三态探针 ✓ / 网络变量 ✓ / bootcmd 红线未动 ✓ / 无变量丢失 ✓")
    else:
        print("[i] 自检: CRC ✓ / 网络变量 ✓ / bootcmd 红线未动 ✓ / 无变量丢失 ✓")
    print("[i] 全部验证通过 — 可写回 (写回后务必 MD5 双侧核对)")

if __name__ == "__main__":
    main()
