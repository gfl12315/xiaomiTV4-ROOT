# U 盘摆放说明（把本目录文件复制到 FAT32 U 盘根目录）

1. U 盘格式化为 **FAT32** 单分区，根目录平铺（不要放子文件夹）
2. 复制本目录 4 个文件到 U 盘根目录，并做两次改名复制：

```
twrp.img        → 原名保留（部分固件识别此名）
twrp.img        → 复制一份改名 xmen.recovery（本系列 U-Boot 原生识别名，主通道）
twrp.img        → 再复制一份改名 recovery.img（部分固件识别此名）
Magisk-v19.1.zip → 原名保留
test_ors.zip     → 原名保留（已 Root 设备的 OpenRecoveryScript 验证包）
aml_autoscript   → 原名保留（本系列固件不生效，其他 Amlogic 固件可用）
```

3. U 盘插电视，按 README「操作步骤」第 10/11 节触发与操作

## 文件用途速查

| 文件 | 用途 |
|---|---|
| twrp.img（+两个改名副本） | U 盘引导 TWRP 的镜像（三命名覆盖不同固件版本识别差异） |
| Magisk-v19.1.zip | 未 Root 设备的 Root 包（Android 6.0.1 实测兼容版） |
| test_ors.zip | OpenRecoveryScript 自动化闭环验证包（零风险：只写 /cache 标记文件） |
| aml_autoscript | U-Boot legacy 脚本（build_autoscript.py 生成；本系列固件未编译对应命令，不生效） |

## 提醒

- U 盘只放这一个盘的文件，一次只插一个 U 盘（fatload usb 0 只枚举第一个设备）
- U 盘引导 TWRP 不修改设备存储；不操作它直接断电重启即回到原系统
- Magisk-v19.1.zip 归其权利人所有，按其许可条款（GPL）分发
