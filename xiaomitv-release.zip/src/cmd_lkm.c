/* cmd_lkm.c — 内核态命令执行通道（无内核头文件手工构建）
 * 机制: 内核线程每 2 秒轮询 /data/local/tmp/kcmd.txt，
 *       发现命令行则经 call_usermodehelper 以 root+全 capability 执行。
 *       用户态用法: echo "getenforce > /data/local/tmp/kcmd_out.txt 2>&1" > kcmd.txt
 * 依赖内核符号(全部经 kallsyms 核对存在): kthread_create_on_node / wake_up_process /
 *   kthread_should_stop / kthread_stop / filp_open / filp_close / kernel_read /
 *   call_usermodehelper / msleep / printk
 */
typedef long long loff_t;
struct file;

extern int printk(const char *fmt, ...);
extern void *kthread_create_on_node(int (*fn)(void *), void *data, int node, const char *namefmt, ...);
extern int wake_up_process(void *task);
extern int kthread_should_stop(void);
extern int kthread_stop(void *task);
extern struct file *filp_open(const char *path, int flags, int mode);
extern int filp_close(struct file *f, void *fl_owner);
extern int kernel_read(struct file *f, loff_t offset, char *buf, unsigned long count);
extern int call_usermodehelper(char *path, char **argv, char **envp, int wait);
extern void msleep(unsigned int msecs);

static void *worker_task = 0;
static char rbuf[1024] = {0};   /* 显式初始化: 进 .data 避开 .bss 组装边界 */

static const char cmdpath[] = "/data/local/tmp/kcmd.txt";
static const char banner[] = "<6>cmd_lkm: kernel command channel online\n";

static int run_command(char *cmd)
{
    char *argv[4];
    argv[0] = "/system/bin/sh";
    argv[1] = "-c";
    argv[2] = cmd;
    argv[3] = 0;
    return call_usermodehelper(argv[0], argv, 0, 2);   /* 2 = UMH_WAIT_PROC */
}

static int runner_fn(void *arg)
{
    printk(banner);
    while (!kthread_should_stop()) {
        msleep(2000);
        struct file *f = filp_open(cmdpath, 0, 0);      /* O_RDONLY */
        if ((unsigned long)f >= (unsigned long)-4096)   /* IS_ERR 值域 */
            continue;
        int n = kernel_read(f, 0, rbuf, sizeof(rbuf) - 1);
        filp_close(f, 0);
        if (n <= 0)
            continue;
        rbuf[n] = 0;
        while (n > 0 && (rbuf[n-1] == '\n' || rbuf[n-1] == '\r'))
            rbuf[--n] = 0;
        if (n == 0)
            continue;
        printk("<6>cmd_lkm: exec: %s\n", rbuf);
        int r = run_command(rbuf);
        printk("<6>cmd_lkm: exit=%d\n", r);
    }
    return 0;
}

int init_module(void)
{
    printk(banner);
    worker_task = kthread_create_on_node(runner_fn, 0, -1, "cmd_lkm_worker");
    if (worker_task == 0 || (unsigned long)worker_task >= (unsigned long)-4096) {
        printk("<6>cmd_lkm: kthread create FAILED\n");
        return -1;
    }
    wake_up_process(worker_task);
    printk("<6>cmd_lkm: worker started\n");
    return 0;
}

void cleanup_module(void)
{
    if (worker_task) {
        kthread_stop(worker_task);
        worker_task = 0;
    }
    printk("<6>cmd_lkm: channel closed\n");
}
