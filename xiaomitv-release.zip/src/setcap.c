/* 给 su 二进制设置 security.capability xattr（VFS_CAP_REVISION_2）：
 * fP = 全 capability 集，su 提权后持全部 32 位 caps。 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/xattr.h>
#include <stdint.h>

int main(int argc, char **argv)
{
    if (argc < 2) {
        fprintf(stderr, "用法: %s <su路径>\n", argv[0]);
        return 1;
    }
    unsigned char buf[20];
    memset(buf, 0, sizeof buf);
    /* magic_etc = VFS_CAP_REVISION_2 (0x02000000) | VFS_CAP_FLAGS_EFFECTIVE (0x1) */
    *(uint32_t *)(buf + 0) = 0x02000001u;
    /* permitted = 全 32 位 capability 集 (chown..setfcap) */
    *(uint32_t *)(buf + 4) = 0xFFFFFFFFu; /* data[0].permitted */
    *(uint32_t *)(buf + 8) = 0;           /* data[0].inheritable */
    *(uint32_t *)(buf + 12) = 0xFFFFFFFFu;/* data[1].permitted */
    *(uint32_t *)(buf + 16) = 0;          /* data[1].inheritable */
    if (setxattr(argv[1], "security.capability", buf, sizeof buf, 0) < 0) {
        fprintf(stderr, "setxattr 失败: %s\n", strerror(errno));
        return 1;
    }
    printf("file caps 已设置: %s\n", argv[1]);
    return 0;
}
