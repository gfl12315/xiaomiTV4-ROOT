/* kcap.c — 全流量 pcap 抓包器（无内核头文件手工构建）
 *
 * 机制: netfilter 双钩（IPv4 PRE_ROUTING+LOCAL_OUT）→ 每包 skb_copy_bits
 *   抓前 128B（递减探测实际长度, EFAULT 时步进回退）→ ring 128 条存
 *   pcap 包记录格式（16B 头 + 数据, LINKTYPE_RAW）→ /proc/kcap 输出
 *   pcap 包记录流 → 用户态落盘脚本补 24B 全局头 → 标准 .pcap（Wireshark 可开）
 *
 * 依赖符号（全部 __ksymtab 已核查）: nf_register_hook / nf_unregister_hook /
 *   skb_copy_bits / getnstimeofday / memcpy / proc_create_data / remove_proc_entry /
 *   printk / __copy_to_user / __copy_from_user
 *
 * /proc/kcap: read = pcap 包记录流; write "off"/"on"/"clear" = 暂停/恢复/清空
 * 落盘: printf <24B 全局头> > f.pcap; cat /proc/kcap >> f.pcap
 */
typedef long long loff_t_;

extern int printk(const char *fmt, ...);
extern int nf_register_hook(void *ops);
extern void nf_unregister_hook(void *ops);
extern int skb_copy_bits(const void *skb, int offset, void *to, int len);
extern int getnstimeofday(void *ts);
extern void *memcpy(void *d, const void *s, unsigned long n);
extern void *memset(void *d, int c, unsigned long n);
extern void *proc_create_data(const char *name, unsigned int mode, void *parent,
                              void *fops, void *data);
extern void remove_proc_entry(const char *name, void *parent);
extern long __copy_to_user(void *to, const void *from, unsigned long n);
extern long __copy_from_user(void *to, const void *from, unsigned long n);

#define NF_ACCEPT_ 1
#define EFAULT_    14

static inline void mem_barrier(void)
{
    __asm__ volatile("dmb ish" ::: "memory");
}
#define NSNAP      128
#define NREC       128
#define RECSZ      (16 + NSNAP)

struct timespec_ { long sec; long nsec; };

static volatile int cap_on = 1;
static volatile unsigned int cap_seq = 0;
static volatile int rec_head = 0;

struct pcap_rec {
    unsigned int ts_sec, ts_usec, incl_len, orig_len;
    unsigned char data[NSNAP];
};
static struct pcap_rec recs[NREC];

/* ===== netfilter 钩子 ===== */
static unsigned int kcap_hook(unsigned int hooknum, void *skb, const void *in,
                              const void *out, int (*okfn)(void *))
{
    struct timespec_ ts;
    struct pcap_rec *r;
    unsigned char buf[NSNAP];
    int got = NSNAP;

    if (!cap_on) return NF_ACCEPT_;
    getnstimeofday(&ts);
    /* skb_copy_bits len 超界即 EFAULT → 步进回退探测实际长度 */
    while (got > 0) {
        if (skb_copy_bits(skb, 0, buf, got) == 0) break;
        got -= 16;
    }
    if (got <= 0) return NF_ACCEPT_;
    r = &recs[rec_head];
    r->ts_sec = (unsigned int)ts.sec;
    r->ts_usec = (unsigned int)(ts.nsec / 1000);
    r->incl_len = (unsigned int)got;
    r->orig_len = (unsigned int)got;
    memcpy(r->data, buf, (unsigned long)got);
    /* 剩余尾部清零(防旧数据混入 pcap) */
    {
        int i;
        for (i = got; i < NSNAP; i++) r->data[i] = 0;
    }
    mem_barrier();
    rec_head = (rec_head + 1) % NREC;
    cap_seq++;
    return NF_ACCEPT_;
}

/* ===== /proc/kcap ===== */
struct my_fops {
    void *owner;
    void *llseek;
    int  (*read)(void *, char *, unsigned long, loff_t_ *);
    int  (*write)(void *, const char *, unsigned long, loff_t_ *);
    void *p1; void *p2; void *p3; void *p4;
    long (*unlocked_ioctl)(void *, unsigned int, unsigned long);
    void *p5; void *p6;
    int  (*open)(void *, void *);
    void *p7;
    int  (*release)(void *, void *);
};

static const char procname[] = "kcap";

/* read: 按 *ppos 字节偏移输出 ring 的 pcap 记录流 (RECSZ 定长槽位) */
static int kcap_read(void *file, char *ubuf, unsigned long len, loff_t_ *ppos)
{
    char out[4096];
    long pos = (long)*ppos;
    long total = (long)NREC * RECSZ;
    long avail = total - pos;
    int n, i;
    if (avail <= 0) return 0;
    n = (int)(avail < (long)sizeof(out) ? avail : (long)sizeof(out));
    n = (int)((unsigned long)n > len ? (long)len : n);
    /* 组装从 pos 起 n 字节 */
    {
        int idx = (int)(pos / RECSZ);
        int off = (int)(pos % RECSZ);
        int wi = 0;
        while (wi < n) {
            struct pcap_rec *r = &recs[idx];
            const char *src = (const char *)r;
            int canslot = RECSZ - off;
            int chunk = n - wi < canslot ? n - wi : canslot;
            for (i = 0; i < chunk; i++) out[wi + i] = src[off + i];
            wi += chunk;
            off = 0;
            idx = (idx + 1) % NREC;
        }
    }
    if (__copy_to_user(ubuf, out, (unsigned long)n)) return -EFAULT_;
    *ppos = pos + n;
    return n;
}

static int kcap_write(void *file, const char *ubuf, unsigned long len, loff_t_ *ppos)
{
    char buf[16];
    unsigned long n = len;
    if (n > sizeof(buf) - 1) n = sizeof(buf) - 1;
    if (__copy_from_user(buf, ubuf, n)) return -EFAULT_;
    buf[n] = 0;
    {
        int i;
        for (i = 0; i < (int)n; i++)
            if (buf[i] == '\n' || buf[i] == '\r') buf[i] = 0;
    }
    if (n == 3 && buf[0] == 'o' && buf[1] == 'f' && buf[2] == 'f') {
        cap_on = 0;
        printk("<6>kcap: capture paused\n");
    } else if (n == 2 && buf[0] == 'o' && buf[1] == 'n') {
        cap_on = 1;
        printk("<6>kcap: capture resumed\n");
    } else if (n == 5 && buf[0] == 'c' && buf[1] == 'l' && buf[2] == 'e' && buf[3] == 'a' && buf[4] == 'r') {
        memset(recs, 0, sizeof(recs));
        rec_head = 0;
        printk("<6>kcap: ring cleared\n");
    }
    return (int)len;
}

static int kcap_open(void *a, void *b) { return 0; }
static int kcap_rel(void *a, void *b) { return 0; }

static struct my_fops kc_fops = {
    0, 0,
    kcap_read, kcap_write,
    0, 0, 0, 0,
    0, 0, 0,
    kcap_open,
    0,
    kcap_rel,
};

/* nf_hook_ops @0x38: list16 hook@0x10 owner@0x18 priv@0x20 pf@0x28 hooknum@0x2c priority@0x30 */
struct my_nfops {
    void *list[2];
    unsigned int (*hook)(unsigned int, void *, const void *, const void *, int (*)(void *));
    void *owner;
    void *priv;
    unsigned char pf;
    unsigned char pad[3];
    unsigned int hooknum;
    int priority;
};

static struct my_nfops cap_in = {
    0, 0, kcap_hook, 0, 0, 2, 0, 0, 0, 0, -120
};
static struct my_nfops cap_out = {
    0, 0, kcap_hook, 0, 0, 2, 0, 0, 0, 3, -119
};

int init_module(void)
{
    int r1 = nf_register_hook(&cap_in);
    int r2 = nf_register_hook(&cap_out);
    if (r1 != 0 || r2 != 0) {
        printk("<6>kcap: register FAILED %d/%d\n", r1, r2);
        if (r1 == 0) nf_unregister_hook(&cap_in);
        if (r2 == 0) nf_unregister_hook(&cap_out);
        return -1;
    }
    if (proc_create_data(procname, 0666, 0, &kc_fops, 0) == 0)
        printk("<6>kcap: proc FAILED\n");
    printk("<6>kcap: full-traffic pcap capture online (v4 in+out)\n");
    return 0;
}

void cleanup_module(void)
{
    nf_unregister_hook(&cap_in);
    nf_unregister_hook(&cap_out);
    remove_proc_entry(procname, 0);
    printk("<6>kcap: offline\n");
}
