/* kctl.c — /dev/kxmen 全权执行设备 + /proc/kxmen 公告栏（无内核头文件手工构建）
 *
 * 结构布局依据 linux 3.14.29 源码（本机留存 include/linux/fs.h / miscdevice.h）:
 *   struct file_operations: owner=0x00 llseek=0x08 read=0x10 write=0x18
 *     aio_read=0x20 aio_write=0x28 iterate=0x30 poll=0x38
 *     unlocked_ioctl=0x40 compat_ioctl=0x48 mmap=0x50 open=0x58 flush=0x60 release=0x68
 *   struct miscdevice: minor=0x00 name=0x08 fops=0x10 list=0x18 parent=0x28
 *     this_device=0x30 nodename=0x38 mode=0x40
 * 未填充字段保持 NULL，内核按偏移读不到函数指针即跳过。
 *
 * 用户态接口:
 *   echo "cmd > /data/local/tmp/out.txt 2>&1" > /dev/kxmen   # 全权执行(即时)
 *   cat /dev/kxmen                                            # 读统计
 *   cat /proc/kxmen                                           # 同上(公告栏)
 *   ioctl(fd, 0x4B01, &stat_block)                            # 结构化状态
 */
typedef long long loff_t_;

extern int printk(const char *fmt, ...);
extern int misc_register(void *misc);
extern int misc_deregister(void *misc);
extern void *proc_create_data(const char *name, unsigned int mode, void *parent,
                              void *fops, void *data);
extern void remove_proc_entry(const char *name, void *parent);
extern long __copy_to_user(void *to, const void *from, unsigned long n);
extern long __copy_from_user(void *to, const void *from, unsigned long n);
extern int call_usermodehelper(char *path, char **argv, char **envp, int wait);
extern struct file *filp_open(const char *path, int flags, int mode);
extern int filp_close(struct file *f, void *fl_owner);
extern int kernel_read(struct file *f, long long offset, char *buf, unsigned long count);

#define IOCTL_GETSTAT 0x4B01
#define EFAULT_ 14
#define ENOTTY_ 25

static char cmdbuf[1024] = {0};        /* 显式初始化: 避开 .bss 组装边界 */
static volatile int exec_count = 0;
static volatile int ok_count = 0;
static volatile int last_ret = 0;
static char last_cmd[96] = {0};

/* ===== token 认证 =====
 * 威胁: permissive 下任何 App 可写 666 的 /dev/kxmen 发全权命令。
 * 防线: 命令必须带前缀 kt:<16hex>| 才执行; token 存 /data/adb/kx.token
 * (0600 root, App 读不到), init 时加载进内核内存。token 缺失=全拒绝。 */
static char ktoken[17] = {0};

static int load_token(void)
{
    struct file *f = filp_open("/data/adb/kx.token", 0, 0);   /* O_RDONLY */
    char buf[32];
    int n, i, j = 0;
    if ((unsigned long)f >= (unsigned long)-4096) return -1;
    n = kernel_read(f, 0, buf, sizeof(buf) - 1);
    filp_close(f, 0);
    if (n <= 0) return -1;
    buf[n] = 0;
    for (i = 0; i < n && j < 16; i++) {
        char c = buf[i];
        if (c >= '0' && c <= '9') ktoken[j++] = c;
        else if (c >= 'a' && c <= 'f') ktoken[j++] = c;
        else if (c >= 'A' && c <= 'Z') ktoken[j++] = c + 32;
    }
    ktoken[j] = 0;
    return j;
}

static int slen(const char *s){ int n = 0; while (s[n]) n++; return n; }
static int seqcmp(const char *a, const char *b, int n)
{
    int i;
    for (i = 0; i < n; i++) if (a[i] != b[i]) return 0;
    return 1;
}

/* 小整数转十进制（避免 snprintf 依赖），返回写入字符数 */
static int dec(char *p, int v)
{
    unsigned int u = (unsigned int)v;
    char tmp[12];
    int n = 0, m = 0;
    if (v < 0) { *p++ = '-'; m++; u = (unsigned int)(-v); }
    if (u == 0) tmp[n++] = '0';
    while (u) { tmp[n++] = (char)('0' + u % 10u); u /= 10u; }
    while (n) p[m++] = tmp[--n];
    return m;
}

/* 拼统计串到 buf, 返回长度 */
static int fill_stats(char *out)
{
    char *p = out;
    static const char s1[] = "kctl: execs=";
    static const char s2[] = " ok=";
    static const char s3[] = " last_ret=";
    static const char s4[] = "\nlast: ";
    static const char s5[] = "\n";
    int i;
    const char *q;
    for (q = s1; *q; q++) *p++ = *q;
    p += dec(p, exec_count);
    for (q = s2; *q; q++) *p++ = *q;
    p += dec(p, ok_count);
    for (q = s3; *q; q++) *p++ = *q;
    p += dec(p, last_ret);
    for (q = s4; *q; q++) *p++ = *q;
    for (i = 0; i < 95 && last_cmd[i]; i++) *p++ = last_cmd[i];
    for (q = s5; *q; q++) *p++ = *q;
    return (int)(p - out);
}

/* 全权执行: /system/bin/sh -c <cmd>, 内核派发 root+全caps
 * 认证: cmd 必须为 kt:<16hex>|<cmd> 形式, token 不符静默丢弃 */
static void kexec(char *cmd)
{
    char *argv[4];
    int r, i;
    if (slen(cmd) < 20 || !seqcmp(cmd, "kt:", 3) || !seqcmp(cmd + 3, ktoken, 16)
        || cmd[19] != '|') {
        printk("<6>kctl: AUTH FAIL drop\n");
        return;
    }
    cmd += 20;
    if (!cmd[0]) return;
    argv[0] = "/system/bin/sh";
    argv[1] = "-c";
    argv[2] = cmd;
    argv[3] = 0;
    exec_count++;
    r = call_usermodehelper(argv[0], argv, 0, 2);   /* 2 = UMH_WAIT_PROC */
    if (r == 0) ok_count++;
    last_ret = r;
    for (i = 0; i < 95 && cmd[i]; i++) last_cmd[i] = cmd[i];
    last_cmd[i] = 0;
    printk("<6>kctl: exec(%s) ret=%d\n", cmd, r);
}

/* ===== fops 处理函数 ===== */

/* write: 收命令即执行 (write@0x18) */
static int kctl_write(void *file, const char *ubuf, unsigned long len, loff_t_ *ppos)
{
    unsigned long n = len;
    if (n > sizeof(cmdbuf) - 1) n = sizeof(cmdbuf) - 1;
    if (__copy_from_user(cmdbuf, ubuf, n)) return -EFAULT_;
    cmdbuf[n] = 0;
    while (n && (cmdbuf[n-1] == '\n' || cmdbuf[n-1] == '\r')) cmdbuf[--n] = 0;
    if (n) kexec(cmdbuf);
    return (int)len;
}

/* read: 返回统计 (read@0x10; /dev 与 /proc 共用) */
static int kctl_read(void *file, char *ubuf, unsigned long len, loff_t_ *ppos)
{
    char out[256];
    int n;
    if (*ppos != 0) return 0;               /* 一次性输出, 二次读返回0结束 */
    n = fill_stats(out);
    if ((unsigned long)n > len) n = (int)len;
    if (__copy_to_user(ubuf, out, (unsigned long)n)) return -EFAULT_;
    *ppos = n;
    return n;
}

/* unlocked_ioctl: 结构化状态查询 (@0x40) */
static long kctl_ioctl(void *file, unsigned int cmd, unsigned long arg)
{
    struct sb { int execs; int oks; int ret; char last[96]; } blk;
    int i;
    if (cmd != IOCTL_GETSTAT) return -ENOTTY_;
    blk.execs = exec_count;
    blk.oks = ok_count;
    blk.ret = last_ret;
    for (i = 0; i < 96; i++) blk.last[i] = last_cmd[i];
    if (__copy_to_user((void *)arg, &blk, sizeof(blk))) return -EFAULT_;
    return 0;
}

static int kctl_open(void *ino, void *filp)   { return 0; }
static int kctl_release(void *ino, void *filp){ return 0; }

/* ===== 结构定义（偏移即 3.14 内核布局） ===== */

struct my_fops {
    void *owner;                                              /* 0x00 NULL */
    void *llseek;                                             /* 0x08 NULL */
    int  (*read)(void *, char *, unsigned long, loff_t_ *);   /* 0x10 */
    int  (*write)(void *, const char *, unsigned long, loff_t_ *); /* 0x18 */
    void *pad1;                                               /* 0x20 aio_read */
    void *pad2;                                               /* 0x28 aio_write */
    void *pad3;                                               /* 0x30 iterate */
    void *pad4;                                               /* 0x38 poll */
    long (*unlocked_ioctl)(void *, unsigned int, unsigned long); /* 0x40 */
    void *pad5;                                               /* 0x48 compat_ioctl */
    void *pad6;                                               /* 0x50 mmap */
    int  (*open)(void *, void *);                             /* 0x58 */
    void *pad7;                                               /* 0x60 flush */
    int  (*release)(void *, void *);                          /* 0x68 */
};

static const char devname[] = "kxmen";
static const char procname[] = "kxmen";

static struct my_fops kx_fops = {
    0, 0,
    kctl_read, kctl_write,
    0, 0, 0, 0,
    kctl_ioctl,
    0, 0,
    kctl_open,
    0,
    kctl_release,
};

struct my_misc {
    int minor;                /* 0x00 */
    const char *name;         /* 0x08 */
    void *fops;               /* 0x10 */
    void *pad[2];             /* 0x18 list(16B) 内核自填 */
    void *parent;             /* 0x28 */
    void *this_device;        /* 0x30 */
    const char *nodename;     /* 0x38 NULL -> /dev/kxmen */
    unsigned int mode;        /* 0x40 */
};

static struct my_misc kx_misc = {
    255,                      /* MISC_DYNAMIC_MINOR */
    devname,
    &kx_fops,
    0, 0,
    0, 0, 0,
    0666,                     /* root/shell 均可访问 */
};

/* ===== 生命周期 ===== */

int init_module(void)
{
    int tl = load_token();
    int r = misc_register(&kx_misc);
    if (r != 0) {
        printk("<6>kctl: misc_register FAILED %d\n", r);
        return -1;
    }
    if (proc_create_data(procname, 0444, 0, &kx_fops, 0) == 0)
        printk("<6>kctl: proc_create_data FAILED (dev still alive)\n");
    printk("<6>kctl: /dev/kxmen + /proc/kxmen online, token %s (%d)\n",
           tl == 16 ? "loaded" : "MISSING-exec-denied", tl);
    return 0;
}

void cleanup_module(void)
{
    remove_proc_entry(procname, 0);
    misc_deregister(&kx_misc);
    printk("<6>kctl: /dev/kxmen + /proc/kxmen offline\n");
}
