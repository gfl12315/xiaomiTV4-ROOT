/* kadblock.c — DNS 捕获 + 内核级广告拦截（无内核头文件手工构建）
 *
 * 机制: netfilter PRE_ROUTING(IPv4) 钩子 → skb_copy_bits 安全读包
 *   → UDP/53 检测 → DNS QNAME 解码 → 记录 ring buffer(任务9: 找广告源)
 *   → 黑名单后缀匹配 → NF_DROP(任务3: 内核级拦截, 广告请求出不了门)
 *
 * 结构布局依据 linux 3.14.29 源码(本机留存):
 *   struct nf_hook_ops: list=0x00(16B) hook=0x10 owner=0x18 priv=0x20
 *     pf=0x28(u8) hooknum=0x2c(uint) priority=0x30(int)  → sizeof=0x38
 *   常量(uapi 实证): NF_DROP=0 NF_ACCEPT=1 NFPROTO_IPV4=2 PRE_ROUTING=0
 *   hook 签名: u32 hookfn(u32 hooknum, skb, in_dev, out_dev, okfn)
 *   skb_copy_bits(skb, offset, buf, len) — 0 成功, 负值失败(自带边界检查)
 *
 * 用户态接口(/proc/kadblock):
 *   cat  → 拦截统计 + 黑名单 + 最近 DNS 查询记录(64 条 ring)
 *   echo "add 广告域名" > /proc/kadblock   (加黑名单, 子域名一并命中)
 *   echo "del 域名" / "clear" / "reset"    (删除/清空/统计清零)
 *   直接写域名 = add
 */
typedef unsigned int u32_;

extern int printk(const char *fmt, ...);
extern int nf_register_hook(void *ops);
extern void nf_unregister_hook(void *ops);
extern int skb_copy_bits(const void *skb, int offset, void *to, int len);
extern void *proc_create_data(const char *name, unsigned int mode, void *parent,
                              void *fops, void *data);
extern void remove_proc_entry(const char *name, void *parent);
extern long __copy_to_user(void *to, const void *from, unsigned long n);
extern long __copy_from_user(void *to, const void *from, unsigned long n);

#define NF_DROP_   0
#define NF_ACCEPT_ 1
#define EFAULT_    14

/* ===== 状态 ===== */
static char blacklist[32][64] = {
    "ad.xiaomi.com", "ad1.ad.xiaomi.com", "api.ad.xiaomi.com",
    "tracking.miui.com", "data.mistat.xiaomi.com", "misstat.xiaomi.com",
};
static unsigned char bl_valid[32] = {1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,
                                     0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
static volatile int raw_total = 0;      /* 无条件计数: hook 被调诊断 */
static volatile int dns_total = 0;      /* 观测到的 DNS 查询总数 */
static volatile int dns_dropped = 0;    /* 拦截的查询数 */
static volatile unsigned int rec_seq = 0;

struct dns_rec { unsigned int seq; char action; char domain[112]; };
static struct dns_rec recs[64] = {{0}};
static volatile int rec_head = 0;       /* 下一写入位置 */
static char cmdbuf[256] = {0};

/* ARM64 内存屏障: 弱内存模型下跨 CPU 状态发布/观测必须显式屏障
 * (volatile 只约束编译器不约束 CPU store buffer; 内核同步原语等效物) */
static inline void mem_barrier(void)
{
    __asm__ volatile("dmb ish" ::: "memory");
}

/* ===== 字符串工具(避免内核 strcmp 依赖) ===== */
static int slen(const char *s){ int n=0; while(s[n]) n++; return n; }
static int seqcmp(const char *a, const char *b, int n){ int i; for(i=0;i<n;i++) if(a[i]!=b[i]) return 0; return 1; }

/* 黑名单后缀匹配: dom==ent 或 dom 以 .ent 结尾 */
static int match_entry(const char *dom, const char *ent)
{
    int dl = slen(dom), el = slen(ent);
    if (el <= 0 || el > dl) return 0;
    if (!seqcmp(dom + dl - el, ent, el)) return 0;
    if (dl == el) return 1;
    return dom[dl - el - 1] == '.';
}

static int hit_blacklist(const char *dom)
{
    int i;
    mem_barrier();                               /* 观测其他 CPU 的规则更新 */
    for (i = 0; i < 32; i++)
        if (bl_valid[i] && match_entry(dom, blacklist[i])) return i;
    return -1;
}

static void add_rec(char action, const char *dom)
{
    struct dns_rec *r = &recs[rec_head];
    int i;
    r->seq = ++rec_seq;
    r->action = action;
    for (i = 0; i < 111 && dom[i]; i++) r->domain[i] = dom[i];
    for (; i < 112; i++) r->domain[i] = 0;      /* 剩余清零: 防旧数据残留乱码 */
    mem_barrier();
    rec_head = (rec_head + 1) % 64;
}

/* DNS wire QNAME → 小写点分文本; 返回长度, -1 失败 */
static int qname_decode(const unsigned char *w, int maxlen, char *out, int outsz)
{
    int wi = 0, oi = 0, j;
    while (wi < maxlen) {
        unsigned char l = w[wi];
        if (l == 0) { out[oi] = 0; return oi; }
        if (l & 0xc0) return -1;                    /* 压缩指针: question 区不该有 */
        wi++;
        if (wi + l > maxlen) return -1;
        if (oi + l + 1 >= outsz) return -1;
        if (oi) out[oi++] = '.';
        for (j = 0; j < l; j++) {
            unsigned char c = w[wi + j];
            out[oi++] = (char)((c >= 'A' && c <= 'Z') ? c + 32 : c);
        }
        wi += l;
    }
    out[oi] = 0;                                     /* 补 NUL: 防 dom 栈残留进 ring */
    return -1;
}

static char td_hb[1];

/* SNI 提取: skb_copy_bits 逐段读 TLS ClientHello
 * 结构: record(5B: 16 03 v v len16) + handshake(01 len24) + ver2 + random32
 *       + sid_len1 + sid + cipher_len2 + ciphers + comp_len1 + comp
 *       + ext_len2 + extensions{ type2 len2 data }
 * SNI ext: type=0x0000, data = list_len2 + type1 + name_len2 + name */
static void sni_probe(const void *skb, int base)
{
    unsigned char rh[5], hh[4], t2[2];
    int rec_len, hs_len, off, sid, cip, comp, exts, ext_end;
    unsigned char name[112];
    int ni = 0, got = 0;
    int i, j;
    char label;
    (void)label;

    if (skb_copy_bits(skb, base, rh, 5) != 0) return;
    if (rh[0] != 0x16) return;                       /* 非 TLS handshake record */
    rec_len = (rh[3] << 8) | rh[4];
    if (skb_copy_bits(skb, base + 5, hh, 1) != 0) return;
    if (hh[0] != 0x01) return;                       /* 非 ClientHello */
    if (skb_copy_bits(skb, base + 6, hh, 3) != 0) return;
    hs_len = (hh[1] << 8) | hh[2];
    off = base + 5 + 4;                              /* handshake 头后 */
    off += 2 + 32;                                   /* version + random */
    if (skb_copy_bits(skb, off, hh, 1) != 0) return; /* session_id_len */
    sid = hh[0];
    off += 1 + sid;
    if (skb_copy_bits(skb, off, t2, 2) != 0) return; /* cipher_len */
    cip = (t2[0] << 8) | t2[1];
    off += 2 + cip;
    if (skb_copy_bits(skb, off, hh, 1) != 0) return; /* comp_len */
    comp = hh[0];
    off += 1 + comp;
    if (skb_copy_bits(skb, off, t2, 2) != 0) return; /* ext 总长 */
    exts = (t2[0] << 8) | t2[1];
    off += 2;
    ext_end = off + exts;
    if (ext_end > base + 5 + rec_len) ext_end = base + 5 + rec_len;

    /* 遍历 extensions 找 SNI (0x0000) */
    while (off + 4 <= ext_end) {
        int etype, elen;
        if (skb_copy_bits(skb, off, t2, 2) != 0) return;
        etype = (t2[0] << 8) | t2[1];
        if (skb_copy_bits(skb, off + 2, t2, 2) != 0) return;
        elen = (t2[0] << 8) | t2[1];
        off += 4;
        if (etype == 0x0000) {
            /* SNI: list_len2 + type1 + name_len2 + name */
            int so = off + 2;                        /* 跳 list_len */
            unsigned char st;
            int nl;
            if (skb_copy_bits(skb, so, hh, 1) != 0) return;
            if (hh[0] != 0x00) return;               /* host_name 类型 */
            if (skb_copy_bits(skb, so + 1, t2, 2) != 0) return;
            nl = (t2[0] << 8) | t2[1];
            if (nl <= 0 || nl > 110) return;
            for (j = 0; j < nl; j++) {
                if (skb_copy_bits(skb, so + 3 + j, hh, 1) != 0) return;
                name[ni++] = (hh[0] >= 'A' && hh[0] <= 'Z') ? hh[0] + 32 : hh[0];
            }
            name[ni] = 0;
            got = 1;
            break;
        }
        off += elen;
    }
    if (!got) return;
    /* 记录: S 前缀入 ring */
    {
        struct dns_rec *r = &recs[rec_head];
        r->seq = ++rec_seq;
        r->action = 'S';
        for (i = 0; i < 111 && name[i]; i++) r->domain[i] = name[i];
        for (; i < 112; i++) r->domain[i] = 0;
        mem_barrier();
        rec_head = (rec_head + 1) % 64;
    }
    printk("<6>kadblock: SNI %s\n", name);
}

/* ===== netfilter 钩子 ===== */
static unsigned int kad_hook(u32_ hooknum, void *skb, const void *in,
                             const void *out, int (*okfn)(void *))
{
    unsigned char iph[20], uhh[8];
    int ihl, dn;
    unsigned char dns[300];
    char dom[120];
    int dlen, hit;

    raw_total++;
    /* 双栈分流: IPv4 变长头(iph[9]=protocol) / IPv6 固定40B头(byte6=next_header, UDP@40) */
    if (skb_copy_bits(skb, 0, iph, 20) != 0) return NF_ACCEPT_;
    if ((iph[0] >> 4) == 6) {                        /* IPv6 */
        if (skb_copy_bits(skb, 6, iph + 9, 1) != 0) return NF_ACCEPT_;  /* next_header */
        ihl = 40;                                    /* 无扩展头假设, UDP 直接 @40 */
    } else {
        ihl = (iph[0] & 0x0f) * 4;
        if (ihl < 20) return NF_ACCEPT_;
    }
    if (iph[9] != 17 && iph[9] != 6) {
        if ((raw_total % 200) == 3)
            printk("<6>kad dbg: other proto=%d\n", iph[9]);
        return NF_ACCEPT_;
    }
    if (skb_copy_bits(skb, ihl, uhh, 8) != 0) return NF_ACCEPT_;
    if (iph[9] == 6) {
        /* TCP/443: TLS ClientHello SNI 提取——看穿一切加密 DNS/HTTPS 访问目标 */
        int td;
        if (skb_copy_bits(skb, ihl + 2, &td_hb[0], 1) != 0) return NF_ACCEPT_;
        td = (td_hb[0] << 8) | uhh[3];               /* 注意: uhh[2..3] 此时是 TCP dport */
        td = (uhh[2] << 8) | uhh[3];
        if (td != 443) return NF_ACCEPT_;
        sni_probe(skb, ihl + 20);                     /* TCP 头 20B (无选项假设) */
        return NF_ACCEPT_;
    }
    if (uhh[2] != 0 || uhh[3] != 53) return NF_ACCEPT_;  /* 仅目的口 53 */
    /* skb_copy_bits 的 len 超过包剩余量时直接 -EFAULT(不部分拷贝)——
     * QNAME 变长, 必须逐字节/逐 label 读, len 永不越界 */
    if (skb_copy_bits(skb, ihl + 8, dns, 12) != 0) return NF_ACCEPT_;  /* DNS 头 12B */
    {
        int wi = 0, qoff = ihl + 8 + 12;
        while (wi < 128) {
            unsigned char b;
            if (skb_copy_bits(skb, qoff + wi, &b, 1) != 0) break;   /* 包读完 */
            dns[12 + wi] = b;
            wi++;
            if (b == 0) break;                                       /* QNAME 结束 */
            if (b & 0xc0) break;                                     /* 压缩指针 */
            if (skb_copy_bits(skb, qoff + wi, dns + 12 + wi, b) != 0) break;
            wi += b;
        }
        dn = 12 + wi;
        if (wi <= 0) return NF_ACCEPT_;
    }
    dlen = qname_decode(dns + 12, dn - 12, dom, 120);
    if (dlen <= 0) return NF_ACCEPT_;

    dns_total++;
    hit = hit_blacklist(dom);
    if (hit >= 0) {
        dns_dropped++;
        add_rec('D', dom);
        printk("<6>kadblock: DROP %s (rule %d)\n", dom, hit);
        return NF_DROP_;
    }
    add_rec('P', dom);
    return NF_ACCEPT_;
}

/* ===== /proc/kadblock ===== */
struct my_fops {
    void *owner;                                                  /* 0x00 */
    void *llseek;                                                 /* 0x08 */
    int  (*read)(void *, char *, unsigned long, long long *);     /* 0x10 */
    int  (*write)(void *, const char *, unsigned long, long long *); /* 0x18 */
    void *p1; void *p2; void *p3; void *p4;                       /* 0x20-0x38 */
    long (*unlocked_ioctl)(void *, unsigned int, unsigned long);  /* 0x40 */
    void *p5; void *p6;                                           /* 0x48 0x50 */
    int  (*open)(void *, void *);                                 /* 0x58 */
    void *p7;                                                     /* 0x60 */
    int  (*release)(void *, void *);                              /* 0x68 */
};

static const char procname[] = "kadblock";

static int kad_read(void *file, char *ubuf, unsigned long len, long long *ppos)
{
    char out[4096];
    char *p = out;
    int n, i;
    static const char h1[] = "kadblock stats: raw=";
    static const char h2[] = " dns_total=";
    static const char h3[] = " dropped=";
    static const char h4b[] = " rules=";

    static const char h5[] = "--- dns ring (D=dropped P=passed) ---\n";
    int m;
    if (*ppos != 0) return 0;

    /* 手拼: raw */
    for (m = 0; h1[m]; m++) *p++ = h1[m];
    {
        int v = raw_total, k = 0; char t[12];
        if (v == 0) t[k++] = '0';
        while (v) { t[k++] = (char)('0' + v % 10); v /= 10; }
        while (k) *p++ = t[--k];
    }
    for (m = 0; h2[m]; m++) *p++ = h2[m];
    {
        int v = dns_total, k = 0; char t[12];
        if (v == 0) t[k++] = '0';
        while (v) { t[k++] = (char)('0' + v % 10); v /= 10; }
        while (k) *p++ = t[--k];
    }
    for (m = 0; h3[m]; m++) *p++ = h3[m];
    {
        int v = dns_dropped, k = 0; char t[12];
        if (v == 0) t[k++] = '0';
        while (v) { t[k++] = (char)('0' + v % 10); v /= 10; }
        while (k) *p++ = t[--k];
    }
    for (m = 0; h4b[m]; m++) *p++ = h4b[m];
    {
        int v = 0, k = 0; char t[12];
        for (i = 0; i < 32; i++) if (bl_valid[i]) v++;
        if (v == 0) t[k++] = '0';
        while (v) { t[k++] = (char)('0' + v % 10); v /= 10; }
        while (k) *p++ = t[--k];
    }
    {
        static const char hr[] = "\n--- rules ---\n";
        for (m = 0; hr[m]; m++) *p++ = hr[m];
    }
    for (i = 0; i < 32; i++)
        if (bl_valid[i]) {
            const char *q = blacklist[i];
            *p++ = '['; { char t[12]; int v = i, k = 0;
                while (v) { t[k++] = (char)('0' + v % 10); v /= 10; }
                while (k) *p++ = t[--k]; } *p++ = ']'; *p++ = ' ';
            while (*q) *p++ = *q++;
            *p++ = '\n';
        }
    for (m = 0; h5[m]; m++) *p++ = h5[m];
    /* ring 按写入顺序展示 */
    for (i = 0; i < 64; i++) {
        struct dns_rec *r = &recs[(rec_head + i) % 64];
        if (r->seq == 0) continue;
        *p++ = r->action; *p++ = ' ';
        { char *q = r->domain; while (*q) *p++ = *q++; }
        *p++ = '\n';
    }
    n = (int)(p - out);
    if ((unsigned long)n > len) n = (int)len;
    if (__copy_to_user(ubuf, out, (unsigned long)n)) return -EFAULT_;
    *ppos = n;
    return n;
}

static int kad_write(void *file, const char *ubuf, unsigned long len, long long *ppos)
{
    unsigned long n = len;
    int ci, i;
    if (n > sizeof(cmdbuf) - 1) n = sizeof(cmdbuf) - 1;
    if (__copy_from_user(cmdbuf, ubuf, n)) return -EFAULT_;
    cmdbuf[n] = 0;
    while (n && (cmdbuf[n-1] == '\n' || cmdbuf[n-1] == '\r')) cmdbuf[--n] = 0;
    if (n == 0) return (int)len;

    if (n == 5 && seqcmp(cmdbuf, "clear", 5)) {
        for (i = 0; i < 32; i++) bl_valid[i] = 0;
        printk("<6>kadblock: rules cleared\n");
        return (int)len;
    }
    if (n == 5 && seqcmp(cmdbuf, "reset", 5)) {
        dns_total = 0; dns_dropped = 0;
        for (i = 0; i < 64; i++) recs[i].seq = 0;
        rec_head = 0; rec_seq = 0;
        printk("<6>kadblock: stats reset\n");
        return (int)len;
    }
    /* add/del: 提取域名部分 */
    {
        const char *dom = cmdbuf;
        int dl = (int)n;
        if (n > 4 && seqcmp(cmdbuf, "add ", 4)) { dom = cmdbuf + 4; dl = (int)n - 4; }
        else if (n > 4 && seqcmp(cmdbuf, "del ", 4)) {
            dom = cmdbuf + 4; dl = (int)n - 4;
            for (i = 0; i < 32; i++)
                if (bl_valid[i] && seqcmp(blacklist[i], dom, dl) && blacklist[i][dl] == 0) {
                    bl_valid[i] = 0;
                    printk("<6>kadblock: del rule %d\n", i);
                }
            return (int)len;
        }
        if (dl <= 0 || dl >= 64) return (int)len;
        /* add: 找空槽 */
        ci = -1;
        for (i = 0; i < 32; i++) if (!bl_valid[i]) { ci = i; break; }
        if (ci < 0) { printk("<6>kadblock: blacklist full\n"); return (int)len; }
        for (i = 0; i < dl; i++) blacklist[ci][i] = dom[i];
        blacklist[ci][dl] = 0;
        mem_barrier();                           /* 先发内容再发 valid 标志 */
        bl_valid[ci] = 1;
        mem_barrier();                           /* valid 发布 */
        printk("<6>kadblock: add rule %d: %s\n", ci, blacklist[ci]);
    }
    return (int)len;
}

static int kad_open(void *i1, void *i2) { return 0; }
static int kad_rel(void *i1, void *i2) { return 0; }

static struct my_fops kad_fops = {
    0, 0,
    kad_read, kad_write,
    0, 0, 0, 0,
    0, 0, 0,
    kad_open,
    0,
    kad_rel,
};

/* nf_hook_ops @0x38: list(16B)/hook=0x10/owner=0x18/priv=0x20/pf=0x28/hooknum=0x2c/priority=0x30 */
struct my_nfops {
    void *list[2];        /* 0x00 内核自填 */
    unsigned int (*hook)(u32_, void *, const void *, const void *, int (*)(void *)); /* 0x10 */
    void *owner;          /* 0x18 NULL */
    void *priv;           /* 0x20 NULL */
    unsigned char pf;     /* 0x28 */
    unsigned char pad[3];
    unsigned int hooknum; /* 0x2c */
    int priority;         /* 0x30 */
};

static struct my_nfops kad_ops4 = {
    0, 0,
    kad_hook,
    0, 0,
    2,                    /* NFPROTO_IPV4 */
    0, 0, 0,              /* pad */
    3,                    /* NF_INET_LOCAL_OUT: 本机出站(DNS 查询在此, 拦截=出不了门) */
    -120,                 /* priority: conntrack 前 */
};

static struct my_nfops kad_ops6 = {
    0, 0,
    kad_hook,
    0, 0,
    10,                   /* NFPROTO_IPV6 */
    0, 0, 0,
    3,                    /* NF_INET_LOCAL_OUT (IPv6 同值枚举) */
    -120,
};

int init_module(void)
{
    int r = nf_register_hook(&kad_ops4);
    if (r != 0) printk("<6>kadblock: reg v4 FAILED %d\n", r);
    r = nf_register_hook(&kad_ops6);
    if (r != 0) printk("<6>kadblock: reg v6 FAILED %d\n", r);
    if (proc_create_data(procname, 0666, 0, &kad_fops, 0) == 0)
        printk("<6>kadblock: proc FAILED\n");
    printk("<6>kadblock: DNS capture + adblock online, dual-stack v4+v6\n");
    return 0;
}

void cleanup_module(void)
{
    nf_unregister_hook(&kad_ops4);
    nf_unregister_hook(&kad_ops6);
    remove_proc_entry(procname, 0);
    printk("<6>kadblock: offline\n");
}
