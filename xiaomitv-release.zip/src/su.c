/* 极简 su：优先 file capabilities 路径（setresuid 真升到 0），退化到 suid 位路径。 */
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

int main(int argc, char **argv)
{
    gid_t g = 0;
    /* 有 file caps 或 suid 位时走这条：直接拿真 root */
    if (setgroups(1, &g) == 0 && setgid(0) == 0 && setuid(0) == 0 && getuid() == 0) {
        /* real root */
    } else if (geteuid() == 0) {
        /* suid 位路径：只有 euid=0，打印提示但不阻塞 */
        fprintf(stderr, "[su] 仅 euid 提升成功（file caps 未设置）\n");
    } else {
        fprintf(stderr, "su: 提权失败: %s\n", strerror(errno));
        return 1;
    }
    if (argc > 1 && !strcmp(argv[1], "-c") && argc > 2) {
        execl("/system/bin/sh", "sh", "-c", argv[2], NULL);
        return 127;
    }
    if (argc > 1) {
        execv(argv[1], &argv[1]);
        return 127;
    }
    execl("/system/bin/sh", "sh", NULL);
    return 127;
}
