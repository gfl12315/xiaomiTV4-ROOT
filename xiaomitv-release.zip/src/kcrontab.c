/* kcrontab.c — 内核态定时守护（kernel-space crontab，无内核头文件手工构建）
 *
 * 机制: kthread 每 1 秒 tick（与 cmd_lkm 同架构，全部符号为已验证导出集）→
 *   任务槽到期判定 → call_usermodehelper(/system/bin/sh -c cmd, UMH_WAIT_PROC)
 *   以 root+全caps+context=u:r:kernel:s0 执行。**用户态死不了的定时器**——
 *   只要内核活着任务就跑，比用户态 crontab 更底层可靠。
 *
 * 任务槽 8 个, 内存态; 持久化由开机脚本喂回:
 *   install-recovery-lkm.sh: cat /data/adb/kcrontab.txt > /proc/kcrontab
 *
 * /proc/kcrontab 接口:
 *   cat   → tick/统计 + 任务清单(含内置)
 *   write "间隔秒|命令"  → 添加任务  例: echo "300|logcat -c" > /proc/kcrontab
 *   write "del N"        → 删第 N 号任务
 *   write "clear"        → 清空全部任务
 *   write "reset"        → 统计清零
 */
typedef long long loff_t_;

extern int printk(const char *fmt, ...);
extern void *kthread_create_on_node(int (*fn)(void *), void *data, int node,
                                    const char *namefmt, ...);
extern int wake_up_process(void *task);
extern int kthread_should_stop(void);
extern int kthread_stop(void *task);
extern int call_usermodehelper(char *path, char **argv, char **envp, int wait);
extern void msleep(unsigned int msecs);
extern void *proc_create_data(const char *name, unsigned int mode, void *parent,
                              void *fops, void *data);
extern void remove_proc_entry(const char *name, void *parent);
extern long __copy_to_user(void *to, const void *from, unsigned long n);
extern long __copy_from_user(void *to, const void *from, unsigned long n);

#define EFAULT_ 14

static void *worker_task = 0;
static volatile int tick = 0;            /* 秒计数 */
static volatile int exec_count = 0;
static volatile int fail_count = 0;

#define NTASK 12    /* 9+ 任务清单: 心跳/日志/ADB/kxmen/printk/BCB/kdns/OTA清理/面板采集 */
/* 纯净版: 无内置任务, 全部由 /proc/kcrontab 喂回(开机脚本自动)。
 * 任务示例(写入 /data/adb/kcrontab.txt, 每行 "间隔秒|命令"):
 *   60|date > /data/local/tmp/kc_alive.txt 2>&1     # 心跳, 外部可查存活
 *   600|logcat -c                                   # 定时清系统日志
 */
static int t_interval[NTASK] = {0, 0, 0, 0, 0, 0, 0, 0};
static int t_last[NTASK] = {0, 0, 0, 0, 0, 0, 0, 0};
static char t_cmd[NTASK][120] = {{0}};
static unsigned char t_valid[NTASK] = {0, 0, 0, 0, 0, 0, 0, 0};

/* ARM64 内存屏障 (跨 CPU 状态发布/观测) */
static inline void mem_barrier(void)
{
    __asm__ volatile("dmb ish" ::: "memory");
}

/* ===== 字符串工具 ===== */
static int slen(const char *s){ int n=0; while(s[n]) n++; return n; }
static int seqcmp(const char *a, const char *b, int n){ int i; for(i=0;i<n;i++) if(a[i]!=b[i]) return 0; return 1; }

/* 小整数转十进制, 返回写入数 */
static int dec(char *p, int v)
{
    unsigned int u = (unsigned int)v;
    char tmp[12];
    int n = 0, m = 0;
    if (v < 0) { *p++ = '-'; m++; u = (unsigned int)(-v); }
    if (u == 0) tmp[n++] = '0';
    while (u) { tmp[n++] = (char)('0' + u % 10u); u /= 10u; }
    while (n) p[m++] = tmp[--n];
    return m;
}

/* 执行一条任务命令 */
static void run_task(const char *cmd)
{
    char *argv[4];
    int r;
    argv[0] = "/system/bin/sh";
    argv[1] = "-c";
    argv[2] = (char *)cmd;
    argv[3] = 0;
    exec_count++;
    r = call_usermodehelper(argv[0], argv, 0, 2);   /* UMH_WAIT_PROC */
    if (r != 0) fail_count++;
    printk("<6>kcrontab: task ret=%d (%s)\n", r, cmd);
}

/* 添加任务: interval 秒 | 命令 */
static int add_task(int interval, const char *cmd, int cl)
{
    int i, j;
    for (i = 0; i < NTASK; i++) {
        if (t_valid[i]) continue;
        if (interval <= 0 || cl <= 0 || cl >= 120) return -1;
        t_interval[i] = interval;
        for (j = 0; j < cl; j++) t_cmd[i][j] = cmd[j];
        t_cmd[i][cl] = 0;
        mem_barrier();                             /* 先发内容再发标志 */
        t_last[i] = tick + interval;               /* 从下一周期起算 */
        t_valid[i] = 1;
        mem_barrier();
        return i;
    }
    return -1;
}

/* ===== 内核线程: 每秒 tick ===== */
static int runner_fn(void *arg)
{
    static const char on[] = "<6>kcrontab: kernel cron online\n";
    printk(on);
    while (!kthread_should_stop()) {
        int i;
        msleep(1000);
        tick++;
        mem_barrier();                             /* 观测 proc 写侧的任务更新 */
        for (i = 0; i < NTASK; i++) {
            if (!t_valid[i]) continue;
            if (tick - t_last[i] >= t_interval[i]) {
                t_last[i] = tick;
                run_task(t_cmd[i]);
            }
        }
    }
    return 0;
}

/* ===== /proc/kcrontab ===== */
struct my_fops {
    void *owner;                                                  /* 0x00 */
    void *llseek;                                                 /* 0x08 */
    int  (*read)(void *, char *, unsigned long, loff_t_ *);       /* 0x10 */
    int  (*write)(void *, const char *, unsigned long, loff_t_ *);/* 0x18 */
    void *p1; void *p2; void *p3; void *p4;                       /* 0x20-0x38 */
    long (*unlocked_ioctl)(void *, unsigned int, unsigned long);  /* 0x40 */
    void *p5; void *p6;                                           /* 0x48 0x50 */
    int  (*open)(void *, void *);                                 /* 0x58 */
    void *p7;                                                     /* 0x60 */
    int  (*release)(void *, void *);                              /* 0x68 */
};

static const char procname[] = "kcrontab";

static int kc_read(void *file, char *ubuf, unsigned long len, loff_t_ *ppos)
{
    char out[2048];
    char *p = out;
    int n, i, m;
    static const char h1[] = "kcrontab: tick=";
    static const char h2[] = " execs=";
    static const char h3[] = " fails=";
    static const char hr[] = "\n--- tasks (interval|last|cmd) ---\n";
    if (*ppos != 0) return 0;

    for (m = 0; h1[m]; m++) *p++ = h1[m];
    p += dec(p, tick);
    for (m = 0; h2[m]; m++) *p++ = h2[m];
    p += dec(p, exec_count);
    for (m = 0; h3[m]; m++) *p++ = h3[m];
    p += dec(p, fail_count);
    for (m = 0; hr[m]; m++) *p++ = hr[m];

    for (i = 0; i < NTASK; i++) {
        if (!t_valid[i]) continue;
        *p++ = '[';
        p += dec(p, i);
        *p++ = ']';
        p += dec(p, t_interval[i]);
        *p++ = '|';
        p += dec(p, t_last[i]);
        *p++ = '|';
        { const char *q = t_cmd[i]; while (*q) *p++ = *q++; }
        *p++ = '\n';
    }
    n = (int)(p - out);
    if ((unsigned long)n > len) n = (int)len;
    if (__copy_to_user(ubuf, out, (unsigned long)n)) return -EFAULT_;
    *ppos = n;
    return n;
}

static int process_line(char *buf, int n)
{
    int i, r;
    if (n == 0) return 0;
    while (n && (buf[n-1] == '\n' || buf[n-1] == '\r')) buf[--n] = 0;
    if (n == 0) return 0;

    if (n == 5 && seqcmp(buf, "clear", 5)) {
        for (i = 0; i < NTASK; i++) t_valid[i] = 0;
        printk("<6>kcrontab: tasks cleared\n");
        return 0;
    }
    if (n == 5 && seqcmp(buf, "reset", 5)) {
        exec_count = 0; fail_count = 0;
        return 0;
    }
    if (n > 4 && seqcmp(buf, "del ", 4)) {
        int idx = 0;
        for (i = 4; i < n && buf[i] >= '0' && buf[i] <= '9'; i++)
            idx = idx * 10 + (buf[i] - '0');
        if (idx >= 0 && idx < NTASK && t_valid[idx]) {
            t_valid[idx] = 0;
            printk("<6>kcrontab: del task %d\n", idx);
        }
        return 0;
    }
    {
        int interval = 0;
        for (i = 0; i < n && buf[i] >= '0' && buf[i] <= '9'; i++)
            interval = interval * 10 + (buf[i] - '0');
        if (i < n && buf[i] == '|' && i + 1 < n) {
            r = add_task(interval, buf + i + 1, n - i - 1);
            if (r >= 0)
                printk("<6>kcrontab: add task %d every %ds: %s\n", r, interval, t_cmd[r]);
            else
                printk("<6>kcrontab: add FAILED (full or bad)\n");
        }
    }
    return 0;
}

static int kc_write(void *file, const char *ubuf, unsigned long len, loff_t_ *ppos)
{
    char buf[1024];      /* 8 任务×120B 命令 + 换行 ≈ 1KB, 喂回整文件须一次容纳 */

    unsigned long n = len;
    int start = 0, i;
    if (n > sizeof(buf) - 1) n = sizeof(buf) - 1;
    if (__copy_from_user(buf, ubuf, n)) return -EFAULT_;
    buf[n] = 0;
    /* 多行支持: 按 \n 切段逐行处理 (cat 文件喂回场景) */
    for (i = 0; i < (int)n; i++) {
        if (buf[i] == '\n') {
            process_line(buf + start, i - start);
            start = i + 1;
        }
    }
    if (start < (int)n)
        process_line(buf + start, (int)n - start);
    return (int)len;
}

static int kc_open(void *a, void *b) { return 0; }
static int kc_rel(void *a, void *b) { return 0; }

static struct my_fops kc_fops = {
    0, 0,
    kc_read, kc_write,
    0, 0, 0, 0,
    0, 0, 0,
    kc_open,
    0,
    kc_rel,
};

int init_module(void)
{
    if (proc_create_data(procname, 0666, 0, &kc_fops, 0) == 0) {
        printk("<6>kcrontab: proc FAILED\n");
        return -1;
    }
    worker_task = kthread_create_on_node(runner_fn, 0, -1, "kcrontab_worker");
    if (worker_task == 0 || (unsigned long)worker_task >= (unsigned long)-4096) {
        remove_proc_entry(procname, 0);
        printk("<6>kcrontab: kthread create FAILED\n");
        return -1;
    }
    wake_up_process(worker_task);
    return 0;
}

void cleanup_module(void)
{
    if (worker_task) {
        kthread_stop(worker_task);
        worker_task = 0;
    }
    remove_proc_entry(procname, 0);
    printk("<6>kcrontab: offline\n");
}
