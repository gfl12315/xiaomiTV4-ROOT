/* kwatch.c — sys_call_table 完整性监控 + 自动自愈（无内核头文件手工构建）
 *
 * 设计参照: ksentinel（512 条目表监控）/ LKRG（周期校验+响应）——
 * 本实现取"检测+自动恢复"（比 LKRG 的 panic 温和, 适配电视长驻）。
 *
 * 机制: init 时对 sys_call_table 全 512 条目拍基线（开机 4.7s 自动加载,
 *   快照时点早于一切第三方模块=干净基线）→ kthread 每 30s 对比 →
 *   篡改: printk 告警 + probe_kernel_write 写回基线（自愈, 绕只读页）→
 *   violations 计数。
 *
 * sys_call_table 地址: 本机 kallsyms 实证 0xffffffc001f73000（未导出,
 *   编译期硬编码; 其他设备用 scripts/extract_addr.py 重新生成）。
 * probe_kernel_write: 已导出（fixmap 写绕 RO 页）。
 *
 * /proc/kwatch: read = 状态/统计; write:
 *   check      → 立即全量校验(结果进 dmesg)
 *   test       → 自演注入测试: 篡改 slot[500](resvd 空槽) → 检出 → 自愈 → 复核
 *   heal on/off → 自愈开关
 */
typedef long long loff_t_;

extern int printk(const char *fmt, ...);
extern void *kthread_create_on_node(int (*fn)(void *), void *data, int node,
                                    const char *namefmt, ...);
extern int wake_up_process(void *task);
extern int kthread_should_stop(void);
extern int kthread_stop(void *task);
extern void msleep(unsigned int msecs);
extern void *proc_create_data(const char *name, unsigned int mode, void *parent,
                              void *fops, void *data);
extern void remove_proc_entry(const char *name, void *parent);
extern long __copy_to_user(void *to, const void *from, unsigned long n);
extern long __copy_from_user(void *to, const void *from, unsigned long n);
extern long probe_kernel_write(void *dst, const void *src, unsigned long n);

#define SCT_ADDR 0xffffffc001f73000UL
#define SCT_N    512
#define EFAULT_  14

static void *worker_task = 0;
static unsigned long sct_base[SCT_N];        /* 基线快照 */
static volatile int violations = 0;
static volatile int heal_on = 1;
static volatile int checks = 0;
static volatile int online = 0;

static inline void mem_barrier(void)
{
    __asm__ volatile("dmb ish" ::: "memory");
}

static int slen(const char *s){ int n = 0; while (s[n]) n++; return n; }
static int seqcmp(const char *a, const char *b, int n)
{
    int i;
    for (i = 0; i < n; i++) if (a[i] != b[i]) return 0;
    return 1;
}

static int dec(char *p, int v)
{
    unsigned int u = (unsigned int)v;
    char tmp[12];
    int n = 0, m = 0;
    if (v < 0) { *p++ = '-'; m++; u = (unsigned int)(-v); }
    if (u == 0) tmp[n++] = '0';
    while (u) { tmp[n++] = (char)('0' + u % 10u); u /= 10u; }
    while (n) p[m++] = tmp[--n];
    return m;
}

/* 全量校验, 返回篡改槽数; 自愈开则写回 */
static int do_check(int heal)
{
    int i, v = 0;
    mem_barrier();
    for (i = 0; i < SCT_N; i++) {
        unsigned long cur = *(unsigned long *)(SCT_ADDR + (unsigned long)i * 8);
        if (cur != sct_base[i]) {
            v++;
            printk("<6>kwatch: [SCT HOOK] slot=%d expected=%p got=%p\n",
                   i, (void *)sct_base[i], (void *)cur);
            if (heal) {
                unsigned long w = sct_base[i];
                if (probe_kernel_write((void *)(SCT_ADDR + (unsigned long)i * 8),
                                       &w, 8) == 0) {
                    printk("<6>kwatch: slot=%d healed\n", i);
                } else {
                    printk("<6>kwatch: slot=%d heal FAILED\n", i);
                }
            }
        }
    }
    checks++;
    if (v) violations += v;
    return v;
}

static int runner_fn(void *arg)
{
    while (!kthread_should_stop()) {
        msleep(30000);
        do_check(heal_on);
    }
    return 0;
}

/* ===== /proc/kwatch ===== */
struct my_fops {
    void *owner;
    void *llseek;
    int  (*read)(void *, char *, unsigned long, loff_t_ *);
    int  (*write)(void *, const char *, unsigned long, loff_t_ *);
    void *p1; void *p2; void *p3; void *p4;
    long (*unlocked_ioctl)(void *, unsigned int, unsigned long);
    void *p5; void *p6;
    int  (*open)(void *, void *);
    void *p7;
    int  (*release)(void *, void *);
};

static const char procname[] = "kwatch";

static int kw_read(void *file, char *ubuf, unsigned long len, loff_t_ *ppos)
{
    char out[512];
    char *p = out;
    int n;
    static const char h1[] = "kwatch: sct@ffffffc001f73000";
    static const char h2[] = " checks=";
    static const char h3[] = " violations=";
    static const char h4[] = " heal=";
    static const char h5[] = "\n";
    int m;
    if (*ppos != 0) return 0;
    for (m = 0; h1[m]; m++) *p++ = h1[m];
    for (m = 0; h2[m]; m++) *p++ = h2[m];
    p += dec(p, checks);
    for (m = 0; h3[m]; m++) *p++ = h3[m];
    p += dec(p, violations);
    for (m = 0; h4[m]; m++) *p++ = h4[m];
    *p++ = heal_on ? '1' : '0';
    for (m = 0; h5[m]; m++) *p++ = h5[m];
    n = (int)(p - out);
    if ((unsigned long)n > len) n = (int)len;
    if (__copy_to_user(ubuf, out, (unsigned long)n)) return -EFAULT_;
    *ppos = n;
    return n;
}

static int kw_write(void *file, const char *ubuf, unsigned long len, loff_t_ *ppos)
{
    char buf[16];
    unsigned long n = len;
    if (n > sizeof(buf) - 1) n = sizeof(buf) - 1;
    if (__copy_from_user(buf, ubuf, n)) return -EFAULT_;
    buf[n] = 0;
    while (n && (buf[n-1] == '\n' || buf[n-1] == '\r')) buf[--n] = 0;   /* 切行必须减 n */
    printk("<6>kw dbg: write len=%d buf=[%s]\n", (int)n, buf);
    if (n == 5 && seqcmp(buf, "check", 5)) {
        int v = do_check(0);
        printk("<6>kwatch: manual check → %d tampered slots\n", v);
    } else if (n == 4 && seqcmp(buf, "test", 4)) {
        /* 自演注入: 篡改 slot[500](resvd 空槽) → 检出 → 自愈 → 复核 */
        unsigned long z = 0xdeadbeefUL;              /* 原值是 0(resvd), 写非零制造差异 */
        int v1, v2;
        long wr;
        wr = probe_kernel_write((void *)(SCT_ADDR + 500UL * 8), &z, 8);
        printk("<6>kw dbg: probe write ret=%ld cur=%px\n", wr,
               (void *)*(unsigned long *)(SCT_ADDR + 500UL * 8));
        v1 = do_check(1);                            /* 应检出 1 并自愈 */
        printk("<6>kw dbg: detect pass v1=%d\n", v1);
        v2 = do_check(0);                            /* 复核应为 0 */
        printk("<6>kwatch: selftest detect=%d after-heal=%d %s\n",
               v1, v2, (v1 == 1 && v2 == 0) ? "PASS" : "FAIL");
    } else if (n == 7 && seqcmp(buf, "heal on", 7)) {
        heal_on = 1;
        printk("<6>kwatch: heal ON\n");
    } else if (n == 8 && seqcmp(buf, "heal off", 8)) {
        heal_on = 0;
        printk("<6>kwatch: heal OFF\n");
    }
    return (int)len;
}

static int kw_open(void *a, void *b) { return 0; }
static int kw_rel(void *a, void *b) { return 0; }

static struct my_fops kw_fops = {
    0, 0,
    kw_read, kw_write,
    0, 0, 0, 0,
    0, 0, 0,
    kw_open,
    0,
    kw_rel,
};

int init_module(void)
{
    int i;
    /* 基线快照: 开机早期加载, 此刻表干净 */
    for (i = 0; i < SCT_N; i++)
        sct_base[i] = *(unsigned long *)(SCT_ADDR + (unsigned long)i * 8);
    if (proc_create_data(procname, 0666, 0, &kw_fops, 0) == 0) {
        printk("<6>kwatch: proc FAILED\n");
        return -1;
    }
    worker_task = kthread_create_on_node(runner_fn, 0, -1, "kwatch_worker");
    if (worker_task == 0 || (unsigned long)worker_task >= (unsigned long)-4096) {
        remove_proc_entry(procname, 0);
        printk("<6>kwatch: kthread FAILED\n");
        return -1;
    }
    wake_up_process(worker_task);
    online = 1;
    printk("<6>kwatch: syscall table integrity monitor online (512 slots, heal=%d)\n",
           heal_on);
    return 0;
}

void cleanup_module(void)
{
    if (worker_task) {
        kthread_stop(worker_task);
        worker_task = 0;
    }
    remove_proc_entry(procname, 0);
    printk("<6>kwatch: offline\n");
}
