# bootloader 分区研究结论（txl_xmen 平台）

> 对象: bootloader 分区 4MB 全镜像（备份导出）的静态分析
> 方法: 熵分布扫描 + 特征字符串提取 + 容器头解析 + 密钥来源判定
> 本文只记录结构与结论，不包含任何设备专属数据

## 分区整体布局（64KB 粒度熵图）

```
0x0000000 eEEEEEEEEEEEEEEEE.0000000000000000000000000000000000000000000000
```

| 区段 | 范围 | 内容 | 状态 |
|---|---|---|---|
| BL2（TPL/DDR init） | 0x0 – 0xC20C | 引导第一阶段: DDR 训练、PLL、FIP 解析、签名检查 | **明文** |
| BL30 容器 | 0xC20C 起，段长 0x3E00 | AMLC 加密容器 | AES-CBC 加密 |
| BL31（ATF）容器 | 0x1020C 起，段长 0xD400 | AMLC 加密容器 | AES-CBC 加密 |
| BL33（U-Boot 本体）容器 | 0x2020C 起，段长 0x1B200 | AMLC 加密容器 | AES-CBC 加密 |
| 附加段容器 | 0x3C20C 起，段长 0xD6200 | AMLC 加密容器 | AES-CBC 加密 |
| 尾部 | 0x130000 – 0x400000 | 全零填充 | — |

## AMLC 加密容器格式

每段头部（0x200B 内）:

```
01 00 01 00 00 00 00 00 "AMLC" <段长×3字段>
[密文数据]
"AES-CBC" + 工具时间戳（本机固件: 2022/11/03 14:19:27）
```

- magic 字面量 `AMLC`，随后 4 字节小端字段中 0x200 为头长度、其余为段大小
- 全部容器共用同一时间戳，即封包时刻
- BL2 字符串区可见 `New fip structure!` / `fip header` / `run bl31` / `bl301` /
  `SIG CHK` / `lock check` —— BL2 按 FIP 思路分发后续级，带签名检查与锁检查
  （失败即复位）

## 密钥来源判定（结论: 软件侧不可解密）

1. BL2 明文区内**无** AES S-box / 逆 S-box（软件 AES 实现特征表）
2. 无 SHA-256 K 常量表
3. 无 efuse 控制器寄存器地址的立即数引用（AES/SHA 走 SoC 硬件加速引擎）
4. 对 BL2 全区 16 字节对齐位置做密钥暴力试解（解密 BL33 首块并检查明文特征）全部失败

综合判定: 解密密钥存放于 efuse 硬件 key 槽，由硬件引擎直接消费，
软件镜像中不存在密钥明文，也不存在可提的派生逻辑。
**BL30/31/33 的软件侧解密不可行**，U-Boot 本体（BL33）无法反编译。

## 对后来者的意义

- 想改 U-Boot 行为，**不要**在 bootloader 分区本体上做——正确路径是 env 分区
  （明文、可写、CRC32 校验、结构简单），本仓库的 env 相关脚本即为此服务
- 本分区研究对象是启动链本身（BL2 → BL30 → BL31 → BL33 的分发与校验逻辑），
  研究价值在 `research/bl_strings.txt`（BL2 全部 1860 个字符串）与
  `research/env_dump.txt`（env 全部 61 个变量的完整模板）
- env 模板中的 serialno/btmac 等字段均为命令模板占位符（`keyman read` 运行期
  从 unifykey 读取），镜像内不含任何设备专属值

## 附: env 关键变量速览（详见 env_dump.txt）

| 变量 | 作用 |
|---|---|
| bootcmd / switch_bootmode | 启动命令链: factory_reset 保护 → upgrade_check → reboot_mode 分发 |
| reboot_mode | cold_boot / normal / factory_reset / update / fastboot（cmd_reboot.c 从 AO_SEC_SD_CFG15 读取） |
| recovery_from_udisk | U 盘引导: fatload aml_autoscript / xmen.recovery → bootm |
| recovery_from_flash | recovery 分区引导（imgread kernel recovery → bootm） |
| update | init_display → permissive → usb start → recovery_from_udisk/flash |
| usb_burning / try_auto_burn | Amlogic USB 烧录模式（配合原厂 Burning Tool） |
| irremote_update | 特定红外码长按 2.5s 触发 update |
| init_display | 开机 logo 显示逻辑（imgread pic logo bootup 系列，按 fb_height 选分辨率） |
| initargs | 内核命令行模板（androidboot.selinux=permissive 在此） |
| storeargs | bootargs 组装（含 cmdline_keys 的 keyman 变量注入） |
